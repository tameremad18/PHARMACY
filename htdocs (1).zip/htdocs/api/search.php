<?php

/*
   API: البحث عن دواء بالاسم (العربي/الإنجليزي/المادة الفعالة)
   GET api/search.php?q=بنادول
   يرجع:
   - medicines: نتائج مخزون الصيدلية
   - kb:        نتائج قاعدة المعرفة الشاملة (خارج المخزون)
   - assistant:        إجابة المساعد الذكي (فقط إذا لم يوجد أي نتائج محلية)
 */

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/assistant.php';

$user = requireLogin();

$q = trim($_GET['q'] ?? '');

if (mb_strlen($q) < 1) {
    jsonReply(['status' => 'ok', 'medicines' => [], 'kb' => []]);
}

$like = '%' . $q . '%';

/* ---------- 1) مخزون الصيدلية ---------- */

$stmt = db()->prepare(
    'SELECT id, name_ar, name_en, generic_name, strength
     FROM medicines
     WHERE name_ar LIKE ? OR name_en LIKE ? OR generic_name LIKE ?
     ORDER BY name_ar
     LIMIT 10'
);

$stmt->execute([$like, $like, $like]);
$medicines = $stmt->fetchAll();

/* ---------- 2) قاعدة المعرفة الشاملة ---------- */

$kbMatches = assistantKbSearch($q, 6);

/* استبعاد ما هو موجود أصلاً في نتائج المخزون (بمطابعة الاسم/المادة الفعالة) */
$localIndex = assistantNormalize(
    implode(' | ', array_merge(
        array_column($medicines, 'name_ar'),
        array_column($medicines, 'name_en'),
        array_column($medicines, 'generic_name')
    ))
);

$kb = [];

foreach ($kbMatches as $entry) {
    $nameAr = assistantNormalize($entry['name_ar']);
    $nameEn = strtolower($entry['name_en']);
    $gener  = assistantNormalize($entry['generic']);

    $inLocal = ($nameAr !== '' && mb_strpos($localIndex, $nameAr) !== false)
            || ($nameEn !== '' && mb_strpos($localIndex, $nameEn) !== false)
            || ($gener !== '' && mb_strpos($localIndex, $gener) !== false);

    if ($inLocal) {
        continue;
    }

    /* هل هو مسجل بالمخزون أصلاً (حتى لو لم يظهر في نتائج LIKE)؟ */
    $inStock = false;

    foreach (assistantPharmacyAll() as $m) {
        $hay = assistantNormalize($m['name_ar'] . ' ' . $m['name_en'] . ' ' . $m['generic_name']);

        if (($nameAr !== '' && mb_strpos($hay, $nameAr) !== false)
            || ($nameEn !== '' && mb_strpos(mb_strtolower($m['name_en'] . ' ' . $m['name_ar']), $nameEn) !== false)
            || ($gener !== '' && mb_strpos($hay, $gener) !== false)) {
            $inStock = true;
            break;
        }
    }

    $entry['in_stock'] = $inStock;
    $kb[] = $entry;
}

$kb = array_slice($kb, 0, 4);

/* ---------- 3) لا نتائج محلية؟ اسأل المزوّد مباشرة ---------- */

$assistantAnswer = null;

if (!$medicines && !$kb && assistantIsEnabled()) {
    $now = time();

    /* نفس ميزانية الشات (كولداون + حد ساعي) حتى لا يُستهلك المفتاح عبر البحث */
    if ($now - (int) ($_SESSION['assistant_last_ask'] ?? 0) >= ASSISTANT_COOLDOWN) {
        $_SESSION['assistant_asked_at'] = array_values(array_filter(
            (array) ($_SESSION['assistant_asked_at'] ?? []),
            fn($t) => $t > $now - 3600
        ));

        if (count($_SESSION['assistant_asked_at']) < ASSISTANT_HOURLY_LIMIT) {
            $_SESSION['assistant_asked_at'][] = $now;
            $_SESSION['assistant_last_ask']   = $now;

            $assistantAnswer = assistantAsk($q, (int) $user['id'])['answer'];
        }
    }
}

jsonReply([
    'status'    => 'ok',
    'medicines' => $medicines,
    'kb'        => $kb,
    'assistant'        => $assistantAnswer,
]);
