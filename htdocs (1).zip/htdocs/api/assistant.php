<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

header('Content-Type: application/json; charset=UTF-8');

try {
    require_once __DIR__ . '/../includes/functions.php';
    require_once __DIR__ . '/../includes/assistant.php';

    $user = requireLogin();

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        echo json_encode(['status' => 'error', 'message' => 'طريقة الطلب غير مسموحة']);
        exit;
    }

    $inputData = json_decode(file_get_contents('php://input'), true);
    $question = trim($inputData['question'] ?? $_POST['question'] ?? '');

    if (mb_strlen($question) < 3 || mb_strlen($question) > 300) {
        echo json_encode(['status' => 'error', 'message' => 'اكتب سؤالاً من 3 إلى 300 حرف']);
        exit;
    }

    $result = assistantAsk($question, (int) $user['id']);

    echo json_encode([
        'status' => 'ok',
        'answer' => $result['answer'] ?? 'عذراً، لم يتم العثور على إجابة.',
        'source' => $result['source'] ?? 'local',
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
    // طباعة خطأ الـ PHP الحقيقي داخل رسالة المساعد لنعرف سببه فوراً
    echo json_encode([
        'status' => 'error',
        'answer' => 'خطأ في السيرفر: ' . $e->getMessage() . ' في السطر ' . $e->getLine(),
        'source' => 'local'
    ], JSON_UNESCAPED_UNICODE);
}
exit;