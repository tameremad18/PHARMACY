<?php

/*
   API: التعرف على الدواء من صورة
   POST api/medscan.php  { image: "<base64 بدون prefix>", mime: "image/jpeg" }
   يتطلب تفعيل المساعد في config/assistant.php
 */

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/assistant.php';

$user = requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonReply(['status' => 'error', 'message' => 'طريقة الطلب غير مسموحة']);
}

/* ---------- حماية من الإفراط ---------- */

$now = time();

if ($now - (int) ($_SESSION['img_last_ask'] ?? 0) < ASSISTANT_COOLDOWN) {
    jsonReply(['status' => 'error', 'message' => 'انتظر قليلاً قبل إرسال صورة أخرى']);
}

/* ---------- قراءة الصورة والتحقق منها ---------- */

$image = trim($_POST['image'] ?? '');
$mime  = trim($_POST['mime'] ?? 'image/jpeg');

if (in_array($mime, ['image/jpg', 'image/pjpeg'], true)) {
    $mime = 'image/jpeg';
}

if ($image === '') {
    jsonReply(['status' => 'error', 'message' => 'لم يتم إرسال الصورة']);
}

if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) {
    jsonReply(['status' => 'error', 'message' => 'صيغة الصورة غير مدعومة']);
}

if (strlen($image) > 6 * 1024 * 1024) {
    jsonReply(['status' => 'error', 'message' => 'حجم الصورة كبير جداً']);
}

if (base64_decode($image, true) === false) {
    jsonReply(['status' => 'error', 'message' => 'بيانات الصورة غير صالحة']);
}

$_SESSION['img_last_ask'] = $now;

/* ---------- التنفيذ ---------- */

if (!assistantIsEnabled()) {
    jsonReply([
        'status'  => 'error',
        'message' => 'التعرف على الأدوية بالصور يحتاج تفعيل المساعد الذكي: ضع مفتاح API في config/assistant.php. يمكنك حالياً البحث بالاسم أو الباركود.',
    ]);
}

$vision = assistantVisionIdentify($image, $mime);

if ($vision === null) {
    jsonReply(['status' => 'error', 'message' => 'تعذر تحليل الصورة، حاول مرة أخرى بصورة أوضح']);
}

if (!$vision['found'] || ($vision['name_ar'] === '' && $vision['name_en'] === '' && $vision['generic'] === '')) {
    jsonReply([
        'status'  => 'ok',
        'found'   => false,
        'message' => 'لم أتمكن من التعرف على الدواء في الصورة بثقة. جرّب صورة أوضح لعلبة الدواء يظهر فيها الاسم، أو ابحث بالاسم في شريط البحث.',
    ]);
}

$name = $vision['name_ar'] !== '' ? $vision['name_ar']
      : ($vision['name_en'] !== '' ? $vision['name_en'] : $vision['generic']);

$local = assistantLocalAnswer($name);

jsonReply([
    'status'   => 'ok',
    'found'    => true,
    'medicine' => [
        'name_ar' => $vision['name_ar'],
        'name_en' => $vision['name_en'],
        'generic' => $vision['generic'],
    ],
    'answer'   => $local,
    'source'   => 'vision',
]);

