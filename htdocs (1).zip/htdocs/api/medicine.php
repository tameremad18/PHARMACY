<?php

/*
   API: تفاصيل الدواء + تسجيل في سجل البحث + المفضلة
   GET  api/medicine.php?id=5        التفاصيل
   POST api/medicine.php?id=5&action=favorite   تبديل المفضلة
*/

require_once __DIR__ . '/../includes/functions.php';

$user = requireLogin();

$id = (int) ($_GET['id'] ?? ($_POST['id'] ?? 0));

if ($id <= 0) {
    jsonReply(['status' => 'error', 'message' => 'معرّف الدواء غير صحيح']);
}

/* ---------- تبديل المفضلة (POST) ---------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'favorite') {
    $stmt = db()->prepare('SELECT id FROM medicines WHERE id = ? LIMIT 1');
    $stmt->execute([$id]);

    if (!$stmt->fetch()) {
        jsonReply(['status' => 'error', 'message' => 'الدواء غير موجود']);
    }

    $stmt = db()->prepare('SELECT id FROM favorites WHERE user_id = ? AND medicine_id = ? LIMIT 1');
    $stmt->execute([$user['id'], $id]);
    $fav = $stmt->fetch();

    if ($fav) {
        $stmt = db()->prepare('DELETE FROM favorites WHERE id = ?');
        $stmt->execute([$fav['id']]);
        jsonReply(['status' => 'ok', 'favorite' => false]);
    }

    $stmt = db()->prepare('INSERT INTO favorites (user_id, medicine_id) VALUES (?, ?)');
    $stmt->execute([$user['id'], $id]);
    jsonReply(['status' => 'ok', 'favorite' => true]);
}

/* ---------- التفاصيل (GET) ---------- */

$stmt = db()->prepare(
    'SELECT m.*, 
            (SELECT COUNT(*) FROM favorites f WHERE f.medicine_id = m.id AND f.user_id = ?) AS is_favorite
     FROM medicines m
     WHERE m.id = ?
     LIMIT 1'
);
$stmt->execute([$user['id'], $id]);
$medicine = $stmt->fetch();

if (!$medicine) {
    jsonReply(['status' => 'error', 'message' => 'الدواء غير موجود']);
}

/* تسجيل عملية البحث في سجل المستخدم */
$stmt = db()->prepare('INSERT INTO search_history (user_id, medicine_id) VALUES (?, ?)');
$stmt->execute([$user['id'], $id]);

$medicine['id']           = (int) $medicine['id'];
$medicine['is_favorite']  = (int) $medicine['is_favorite'] === 1;
$medicine['price']        = (float) $medicine['price'];
$medicine['quantity']     = (int) $medicine['quantity'];

jsonReply(['status' => 'ok', 'medicine' => $medicine]);
