<?php

/*
   API: سجل البحث للمستخدم
   GET api/history.php
*/

require_once __DIR__ . '/../includes/functions.php';

$user = requireLogin();

$stmt = db()->prepare(
    'SELECT m.id, m.name_ar, m.name_en, m.strength, h.searched_at
     FROM search_history h
     JOIN medicines m ON m.id = h.medicine_id
     WHERE h.user_id = ?
     ORDER BY h.searched_at DESC
     LIMIT 10'
);
$stmt->execute([$user['id']]);

jsonReply([
    'status'  => 'ok',
    'history' => $stmt->fetchAll(),
]);
