<?php

/*
   API: البحث عن دواء بالباركود
   GET api/barcode.php?code=6281000000012
   GET api/barcode.php?code=...&assistant=1   (مرحلة ثانية: محاولة المزوّد الخارجي)

   المرحلة 1 (بدون استدعاء خارجي): تطابق محلي فوري — UPC/EAN + تشابه تقريبي
   المرحلة 2 (assistant=1): فقط للباركود غير المسجل — يبحث في قاعدة الأدوية
 */

require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/assistant.php';

$user = requireLogin();

$raw  = trim($_GET['code'] ?? '');
$code = preg_replace('/\D/', '', $raw);

if ($code === '') {
    jsonReply(['status' => 'error', 'message' => 'لم يتم إرسال الباركود']);
}

/* ---------- صور الباركود المحتملة (UPC/EAN) ---------- */

$variants = array_unique(array_filter([$code]));

if (strlen($code) === 13 && $code[0] === '0') {
    $variants[] = substr($code, 1);            /* EAN-13 بصفر -> UPC-A 12 */
}

if (strlen($code) === 12) {
    $variants[] = '0' . $code;                 /* UPC-A -> EAN-13 */
}

/* ---------- 1) مطابقة مباشرة ---------- */

$placeholders = implode(',', array_fill(0, count($variants), '?'));
$stmt = db()->prepare("SELECT id FROM medicines WHERE barcode IN ($placeholders) LIMIT 1");
$stmt->execute($variants);
$medicine = $stmt->fetch();

if ($medicine) {
    jsonReply(['status' => 'ok', 'found' => true, 'id' => (int) $medicine['id']]);
}

/* ---------- 2) مطابقة متسامحة (باركود مخزن بحروف/مسافات زائدة) ---------- */

$stmt = db()->query('SELECT id, barcode FROM medicines WHERE barcode IS NOT NULL');

foreach ($stmt->fetchAll() as $row) {
    $stored = preg_replace('/\D/', '', (string) $row['barcode']);

    if ($stored !== '' && in_array($stored, $variants, true)) {
        jsonReply(['status' => 'ok', 'found' => true, 'id' => (int) $row['id']]);
    }
}

/* ---------- غير مسجل محلياً ---------- */

$message = 'الباركود ' . $code . ' غير مسجل في مخزون الصيدلية.';

/* المرحلة الثانية: اللجوء إلى المساعد عند الطلب الصريح ?assistant=1 */
if (($_GET['assistant'] ?? '') === '1' && assistantIsEnabled()) {
    $now = time();

    if ($now - (int) ($_SESSION['bc_last_ask'] ?? 0) >= ASSISTANT_COOLDOWN) {
        $_SESSION['bc_last_ask'] = $now;

        $country = str_starts_with($code, '628') ? 'السودان' : 'غير محدد';

        $question =
            'مسح مستخدم باركود دواء (EAN-13) رقمه: ' . $code . ' (بلد التسجيل حسب البادئة: ' . $country . '). ' .
            'إن كنت تعرف هذا المنتج تحديداً من رقم الباركود فاذكره باسمه التجاري ومادته الفعالة والشركة المنتجة. ' .
            'رقم الباركود وحده غالباً لا يكفي لتحديد المنتج — إن لم تكن متأكداً تماماً فاعتذر بصراحة ' .
            'واقترح: كتابة الاسم الظاهر على العلبة، أو تصوير العلبة لتعرفها بالصورة. لا تخمن إطلاقاً.';

        $assistantHint = assistantCallApi($question, (int) $user['id']);

        jsonReply([
            'status'  => 'ok',
            'found'   => false,
            'code'    => $code,
            'message' => $message,
            'assistantHint' => $assistantHint,
        ]);
    }
}

/* المرحلة الأولى: رد فوري بدون انتظار */
jsonReply([
    'status'  => 'ok',
    'found'   => false,
    'code'    => $code,
    'message' => $message,
]);
