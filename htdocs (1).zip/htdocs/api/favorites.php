<?php

/*
   API: قائمة الأدوية المفضلة للمستخدم
   GET api/favorites.php
*/

require_once __DIR__ . '/../includes/functions.php';

$user = requireLogin();

$stmt = db()->prepare(
    'SELECT m.id, m.name_ar, m.name_en, m.strength
     FROM favorites f
     JOIN medicines m ON m.id = f.medicine_id
     WHERE f.user_id = ?
     ORDER BY f.created_at DESC'
);
$stmt->execute([$user['id']]);

jsonReply([
    'status' => 'ok',
    'favorites' => $stmt->fetchAll(),
]);
