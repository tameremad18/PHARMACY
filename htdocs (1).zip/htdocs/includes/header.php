<?php

/*
   رأس الصفحة المشترك (Template Header)
   المتغيرات المتاحة قبل التضمين:
   $pageTitle   عنوان الصفحة
   $userSite    صفحات المستخدم (true) لتفعيل روابط الخدمات
   $isAdminArea لوحة تحكم المدير (true) لإخفاء ملاحة المستخدم
*/

require_once __DIR__ . '/functions.php';

$pageTitle   = $pageTitle ?? 'Smart Pharmacy';
$userSite    = $userSite ?? false;
$isAdminArea = $isAdminArea ?? false;
$hideSiteNav = $hideSiteNav ?? false;
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#FFFFFF">

<title><?= e($pageTitle) ?></title>

<link href="<?= url('assets/css/fonts.css') ?>" rel="stylesheet">

<link href="<?= url('assets/css/style.css') ?>" rel="stylesheet">

</head>


<body>

<div class="toast-box" id="toastBox"></div>

<?php if (!$isAdminArea && !$hideSiteNav): ?>

<!-- شريط التنقل العلوي -->
<nav class="site-nav">
    <div class="site-nav-inner">

        <a class="brand" href="<?= isLoggedIn() ? url('home.php') : url('auth/login.php') ?>">
            <span class="brand-text">
                <strong>Smart Pharmacy</strong>
                <small>الصيدلية الذكية</small>
            </span>
        </a>

        <?php if ($userSite): ?>
        <div class="nav-links">
            <a href="<?= url('home.php') ?>" aria-current="page">الرئيسية</a>
            <a href="#" data-bs-toggle="modal" data-bs-target="#assistantChatModal">المساعد الذكي</a>
            <a href="#" onclick="showFavorites(); return false;">المفضلة</a>
            <a href="#" onclick="showHistory(); return false;">سجل البحث</a>
        </div>
        <?php endif; ?>

        <div class="nav-actions">
            <?php if (isLoggedIn()): ?>
                <?php if (isAdmin()): ?>
                    <a class="btn-pill sm" href="<?= url('admin/medicines.php') ?>">
                        لوحة التحكم
                    </a>
                <?php endif; ?>
                <a class="btn-pill sm ghost" href="<?= url('auth/logout.php') ?>">
                    خروج
                </a>
            <?php else: ?>
                <a class="btn-pill sm dark" href="<?= url('auth/login.php') ?>">تسجيل الدخول</a>
                <a class="btn-pill sm ghost" href="<?= url('auth/register.php') ?>">إنشاء حساب</a>
            <?php endif; ?>
        </div>

    </div>
</nav>
<?php endif; ?>