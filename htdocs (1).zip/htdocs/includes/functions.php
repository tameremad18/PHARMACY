<?php

/*
   دوال مساعدة: الجلسات + المصادقة + الحماية
*/

require_once __DIR__ . '/../config/database.php';

/* حدّ تنبيه المخزون المنخفض — مصدر واحد للرقم في كل المشروع */
if (!defined('LOW_STOCK_MAX')) {
    define('LOW_STOCK_MAX', 20);
}

if (session_status() === PHP_SESSION_NONE) {
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => $secure,
    ]);
    session_start();
}

/** تهريب أي نص قبل طباعته في HTML (حماية من XSS) */
function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/** الرابط الأساسي للمشروع (يعمل من أي مجلد) */
function baseUrl(): string
{
    static $base = null;

    if ($base === null) {
        $docRoot = rtrim(str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'] ?? '')), '/');
        $project = rtrim(str_replace('\\', '/', dirname(__DIR__)), '/');
        $path    = ($docRoot !== '' && strpos($project, $docRoot) === 0)
            ? substr($project, strlen($docRoot))
            : '';
        $base = ($path === '' ? '' : $path) . '/';
    }

    return $base;
}

/** إنشاء رابط داخل المشروع */
function url(string $path): string
{
    return baseUrl() . ltrim($path, '/');
}

/** المستخدم الحالي (من الجلسة) أو null */
function currentUser(): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }

    static $user = null;

    if ($user === null) {
        $stmt = db()->prepare('SELECT id, name, email, role FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch() ?: null;
    }

    return $user;
}

function isLoggedIn(): bool
{
    return currentUser() !== null;
}

function isAdmin(): bool
{
    $user = currentUser();
    return $user !== null && $user['role'] === 'admin';
}

/** إجبار الصفحة على تسجيل الدخول */
function requireLogin(): array
{
    $user = currentUser();

    if ($user === null) {
        header('Location: ' . url('auth/login.php'));
        exit;
    }

    return $user;
}

/** إجبار الصفحة على صلاحيات المدير */
function requireAdmin(): array
{
    $user = requireLogin();

    if ($user['role'] !== 'admin') {
        header('Location: ' . url('home.php'));
        exit;
    }

    return $user;
}

/** رد JSON موحّد لواجهات الـ API */
function jsonReply(array $data): void
{
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/** إعادة التوجيه */
function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}
