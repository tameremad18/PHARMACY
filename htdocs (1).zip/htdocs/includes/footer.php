<!-- Footer المشترك -->

<script src="<?= url('assets/js/ui.js') ?>"></script>

<script>
    const APP_URL       = "<?= baseUrl() ?>";
    const LOW_STOCK_MAX = <?= (int) LOW_STOCK_MAX ?>;
</script>

<script src="<?= url('assets/js/app.js') ?>"></script>

<?php if (!empty($extraScripts)): ?>
    <?php foreach ($extraScripts as$script): ?>
        <script src="<?= url($script) ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>

<!-- كود المساعد الذكي المدمج (محدث لتجاوز تحذيرات الوصول وخوانق الاستضافة) -->
<script>
function openAssistantModal() {
    var modal = document.getElementById('assistantChatModal');
    if (modal) {
        modal.style.display = 'block';
        modal.classList.add('show');
        
        // إزالة خاصية الإخفاء وضبط الوصول لمنع أي تحذيرات في الـ Console
        modal.removeAttribute('aria-hidden');
        modal.setAttribute('aria-modal', 'true');
        
        modal.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
        document.body.classList.add('modal-open');
        
        setTimeout(function() {
            var input = document.getElementById('assistantInput');
            if (input) input.focus();
        }, 100);
    }
}

function closeAssistantModal() {
    var modal = document.getElementById('assistantChatModal');
    if (modal) {
        modal.style.display = 'none';
        modal.classList.remove('show');
        
        // إعادة ضبط خصائص الإخفاء عند الإغلاق
        modal.setAttribute('aria-hidden', 'true');
        modal.removeAttribute('aria-modal');
        
        modal.style.backgroundColor = '';
        document.body.classList.remove('modal-open');
    }
}

function assistantSendQuestion() {
    const input = document.getElementById('assistantInput');
    const messagesContainer = document.getElementById('assistantMessages');
    
    if (!input || !input.value.trim()) return;

    const question = input.value.trim();
    input.value = '';

    if (messagesContainer) {
        messagesContainer.innerHTML += `<div class="user-message mb-2 text-end"><b>أنت:</b> ${escapeHtml(question)}</div>`;
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    fetch(APP_URL + 'api/assistant.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ question: question })
    })
    .then(response => response.json())
    .then(data => {
        if (messagesContainer) {
            const reply = data.answer || data.error || 'عذراً، حدث خطأ في الرد.';
            messagesContainer.innerHTML += `<div class="assistant-message mb-2 text-start"><b>المساعد:</b> ${escapeHtml(reply)}</div>`;
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        if (messagesContainer) {
            messagesContainer.innerHTML += `<div class="text-danger mb-2">عذراً، تعذر الاتصال بالخادم.</div>`;
        }
    });
}

function escapeHtml(text) {
    var map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, function(m) { return map[m]; });
}

document.addEventListener('DOMContentLoaded', function() {
    var closeBtns = document.querySelectorAll('#assistantChatModal .btn-close, #assistantChatModal [data-bs-dismiss="modal"]');
    closeBtns.forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            closeAssistantModal();
        });
    });

    var input = document.getElementById('assistantInput');
    if (input) {
        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                assistantSendQuestion();
            }
        });
    }
});
</script>

</body>
</html>