<?php

/*
   مكتبة المساعد الذكي للأدوية
   - assistantAsk():        المساعد الذكي (API خارجي + محرك محلي)
   - assistantLocalAnswer(): محرك بحث ذكي محلي بدون إنترنت
   - assistantKbSearch():    بحث في قاعدة معرفة الأدوية الشاملة
   تتطلب config/assistant.php + config/database.php + includes/drugs.php
 */

require_once __DIR__ . '/../config/assistant.php';

if (!function_exists('db')) {
    require_once __DIR__ . '/../config/database.php';
}

require_once __DIR__ . '/drugs.php';

/*
   1) الإعدادات والحالة
*/

function assistantEndpoints(): array
{
    return [
        'openai'     => 'https://api.openai.com/v1/chat/completions',
        'openrouter' => 'https://openrouter.ai/api/v1/chat/completions',
        'deepseek'   => 'https://api.deepseek.com/chat/completions',
    ];
}

function assistantIsEnabled(): bool
{
    return defined('ASSISTANT_API_KEY') && trim(ASSISTANT_API_KEY) !== '';
}

function assistantDisclaimer(): string
{
    return 'تنبيه: هذه معلومات إرشادية فقط ولا تُغني عن استشارة الطبيب أو الصيدلي.';
}

/*
   2) معالجة النص العربي (توحيد الحروف وإزالة الزوائد)
*/

function assistantNormalize(string $text): string
{
    $text = mb_strtolower(trim($text));

    $text = preg_replace('/[\x{064B}-\x{065F}\x{0670}]/u', '', $text); // التشكيل
    $text = str_replace(['؟', '،', '؛', '«', '»', '…'], ' ', $text);    // ترقيم عربي
    $text = str_replace(['أ', 'إ', 'آ'], 'ا', $text);
    $text = str_replace(['ى', 'ئ'], 'ي', $text);
    $text = str_replace('ؤ', 'و', $text);
    $text = str_replace('ة', 'ه', $text);
    $text = preg_replace('/[^\p{Arabic}a-z0-9\s]/u', ' ', $text);

    return trim(preg_replace('/\s+/', ' ', $text));
}

/*
   3) أدوات مطابقة النصوص
*/

function assistantStopWords(): array
{
    return [
        'دواء', 'دوا', 'ادويه', 'دويه', 'علاج', 'يستخدم', 'موجود', 'اسمه', 'غير',
        'حبوب', 'عندك', 'عندنا', 'ممكن', 'اعرف', 'عايز', 'اريد', 'لازم', 'سؤال',
        'صيدليه', 'صيدلية', 'ايه', 'ماذا', 'هل', 'في', 'من', 'علي', 'عن', 'مع',
        'انا', 'انت', 'هذا', 'هذه', 'ذلك', 'الذي', 'التي', 'كل', 'بعد', 'قبل',
        'ايش', 'ليش', 'وش', 'كده', 'زي', 'برضو', 'فين', 'كيف', 'لماذا',
    ];
}

function assistantWordVariants(string $word): array
{
    $variants = [$word];
    $longPrefixes  = ['وال', 'فال', 'بال', 'كال', 'لل', 'ال'];
    $shortPrefixes = ['و', 'ف', 'ب', 'ل', 'ك'];
    $current = $word;

    for ($i = 0; $i < 2; $i++) {
        $stripped = null;

        foreach ($longPrefixes as $p) {
            if (mb_strpos($current, $p) === 0) {
                $rest = mb_substr($current, mb_strlen($p));
                if (mb_strlen($rest) >= 3) {
                    $stripped = $rest;
                }
                break;
            }
        }

        if ($stripped === null && $i === 0) {
            foreach ($shortPrefixes as $p) {
                if (mb_strpos($current, $p) === 0) {
                    $rest = mb_substr($current, mb_strlen($p));
                    if (mb_strlen($rest) >= 5) {
                        $stripped = $rest;
                    }
                    break;
                }
            }
        }

        if ($stripped === null) {
            break;
        }

        $variants[] = $stripped;
        $current    = $stripped;
    }

    return array_unique($variants);
}

function assistantQuestionWords(string $question): array
{
    $normalized = assistantNormalize($question);
    $stop       = assistantStopWords();
    $words = [];

    foreach (explode(' ', $normalized) as $w) {
        if (mb_strlen($w) < 3) {
            continue;
        }

        foreach (assistantWordVariants($w) as $v) {
            if (mb_strlen($v) >= 3 && !in_array($v, $stop, true)) {
                $words[] = $v;
            }
        }
    }

    return array_values(array_unique($words));
}

function assistantQuestionPhrases(string $question): array
{
    $normalized = assistantNormalize($question);
    $stop       = assistantStopWords();
    $tokens = [];

    foreach (explode(' ', $normalized) as $w) {
        if (mb_strlen($w) >= 3 && !in_array($w, $stop, true)) {
            $tokens[] = $w;
        }
    }

    $phrases = [];
    for ($i = 0, $n = count($tokens) - 1; $i < $n; $i++) {
        $phrases[] = $tokens[$i] . ' ' . $tokens[$i + 1];
    }

    return $phrases;
}

function assistantScoreWords(array $words, string $haystack, array $phrases = []): int
{
    $score = 0;
    foreach ($words as $w) {
        if (mb_strpos($haystack, $w) !== false) {
            $score += mb_strlen($w);
        }
    }

    foreach ($phrases as $p) {
        if (mb_strpos($haystack, $p) !== false) {
            $score += 2 * mb_strlen($p);
        }
    }

    return $score;
}

function assistantKbSearch(string $question, int $limit = 3): array
{
    $words   = assistantQuestionWords($question);
    $phrases = assistantQuestionPhrases($question);

    if (!$words) {
        return [];
    }

    $scored = [];
    foreach (drugsKnowledgeBase() as $entry) {
        $haystack = assistantNormalize(
            $entry['name_ar'] . ' ' . $entry['name_en'] . ' ' .
            $entry['generic'] . ' ' . $entry['category'] . ' ' .
            $entry['uses']
        );

        $score = assistantScoreWords($words, $haystack, $phrases);
        if ($score > 0) {
            $scored[] = ['entry' => $entry, 'score' => $score];
        }
    }

    usort($scored, fn($a, $b) => $b['score'] <=> $a['score']);
    return array_slice(array_column($scored, 'entry'), 0, $limit);
}

function assistantBuildContext(int $userId, string $question = ''): string
{
    $medicines = db()->query(
        'SELECT name_ar, name_en, generic_name, strength, price, quantity
         FROM medicines ORDER BY name_ar'
    )->fetchAll(PDO::FETCH_ASSOC);

    $outOfStock = count(array_filter($medicines, fn($m) => ((int) $m['quantity']) <= 0));

    $lines = [
        sprintf('مخزون الصيدلية: %d دواء مسجل، منها %d متوفر حالياً.', count($medicines), count($medicines) - $outOfStock),
    ];

    $allNames = array_map(
        fn($m) => $m['name_ar'] . (((int) $m['quantity']) > 0 ? '' : ' (غير متوفر)'),
        array_slice($medicines, 0, 300)
    );

    foreach (array_chunk($allNames, 15) as $chunk) {
        $lines[] = implode('، ', $chunk);
    }

    if ($question !== '') {
        $words   = assistantQuestionWords($question);
        $phrases = assistantQuestionPhrases($question);

        if ($words) {
            $scored = [];
            foreach ($medicines as $m) {
                $haystack = assistantNormalize(
                    $m['name_ar'] . ' ' . $m['name_en'] . ' ' .
                    $m['generic_name'] . ' ' . $m['strength']
                );
                $score = assistantScoreWords($words, $haystack, $phrases);
                if ($score > 0) {
                    $scored[] = ['m' => $m, 's' => $score];
                }
            }

            usort($scored, fn($a, $b) => $b['s'] <=> $a['s']);

            if ($scored) {
                $lines[] = 'أدوية الصيدلية الأقرب لسؤال المستخدم:';
                foreach (array_slice($scored, 0, 15) as $t) {
                    $m     = $t['m'];
                    $stock = ((int) $m['quantity']) > 0 ? 'متوفر' : 'غير متوفر حالياً';
                    $lines[] = "- {$m['name_ar']} ({$m['name_en']}) | المادة الفعالة: {$m['generic_name']} | {$m['strength']} | السعر: {$m['price']} | المخزون: {$stock}";
                }
            }
        }

        $kbTop = assistantKbSearch($question, 8);
        if ($kbTop) {
            $lines[] = 'معلومات من قاعدة معرفة الأدوية (اعتمد عليها في الإجابة):';
            foreach ($kbTop as $k) {
                $lines[] = "- {$k['name_ar']} ({$k['name_en']}) | المادة الفعالة: {$k['generic']} | التصنيف: {$k['category']} | الاستخدام: {$k['uses']} | الجرعة المعتادة: {$k['dose']} | تحذيرات: {$k['warnings']}";
            }
        }
    }

    $stmt = db()->prepare(
        'SELECT m.name_ar FROM search_history sh
         JOIN medicines m ON m.id = sh.medicine_id
         WHERE sh.user_id = ? ORDER BY sh.searched_at DESC LIMIT 5'
    );
    $stmt->execute([$userId]);
    $recent = $stmt->fetchAll(PDO::FETCH_COLUMN);

    if ($recent) {
        $lines[] = 'آخر أدوية بحث عنها المستخدم: ' . implode('، ', $recent);
    }

    return implode("\n", $lines);
}

function assistantSystemPrompt(int $userId, string $question = ''): string
{
    return
        "أنت \"صيدلي الذكي\" مساعد تطبيق Smart Pharmacy.\n" .
        "أجب دائماً باللغة العربية بشكل مختصر وواضح (بحد أقصى 150 كلمة).\n" .
        "تحت تصرفك قائمة أسماء كل أدوية الصيدلية وأسعارها وتوفرها، وأدوية الأقرب لسؤال المستخدم بتفاصيلها.\n" .
        "كذلك معلومات موثوقة من قاعدة معرفة شاملة تضم أكثر من 140 دواءً شائعاً (الاستخدام، الجرعة، التحذيرات) — اعتمد عليها عند السؤال عن أي دواء عام.\n" .
        "اعتمد على قائمة أدوية الصيدلية المرفقة عند ذكر الأدوية والأسعار والتوفر.\n" .
        "إذا سُئلت عن دواء غير موجود في القائمة وضّح ذلك بصراحة.\n" .
        "لا تصف علاجاً أو جرعة محددة، وقدّم معلومات عامة فقط.\n" .
        "أنهِ أي إجابة تتعلق بالدواء بتنبيه بضرورة استشارة الطبيب أو الصيدلي.\n\n" .
        assistantBuildContext($userId, $question);
}

/*
   4) الاتصال بمزوّد الخدمة
*/

function assistantCallApi(string $question, int $userId): ?string
{
    if (!assistantIsEnabled()) {
        return null;
    }

    $provider = strtolower(trim(ASSISTANT_PROVIDER));
    $messages = [
        ['role' => 'system', 'content' => assistantSystemPrompt($userId, $question)],
        ['role' => 'user',   'content' => $question],
    ];

    if ($provider === 'gemini') {
        $url     = 'https://generativelanguage.googleapis.com/v1beta/models/'
                 . rawurlencode(ASSISTANT_MODEL) . ':generateContent?key=' . rawurlencode(ASSISTANT_API_KEY);
        $payload = [
            'systemInstruction' => ['parts' => [['text' => $messages[0]['content']]]],
            'contents'          => [['role' => 'user', 'parts' => [['text' => $question]]]],
            'generationConfig'  => [
                'temperature'     => 0.4,
                'maxOutputTokens' => 1500,
            ],
        ];
        $extract = function (array $data): ?string {
            return $data['candidates'][0]['content']['parts'][0]['text'] ?? null;
        };
    } else {
        $url     = assistantEndpoints()[$provider] ?? assistantEndpoints()['openai'];
        $payload = [
            'model'       => ASSISTANT_MODEL,
            'messages'    => $messages,
            'temperature' => 0.4,
            'max_tokens'  => 1500,
        ];
        $extract = function (array $data): ?string {
            return $data['choices'][0]['message']['content'] ?? null;
        };
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST            => true,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
        CURLOPT_TIMEOUT         => (int) ASSISTANT_TIMEOUT,
        CURLOPT_CONNECTTIMEOUT => 10,
    ]);
    $response = curl_exec($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($response === false || $httpCode !== 200) {
        error_log("Assistant cURL Error: " . $curlError . " | HTTP Code: " . $httpCode);
        return null;
    }

    $data  = json_decode($response, true);
    $reply = $extract($data);

    return $reply !== null ? trim($reply) : null;
}

/*
   5) المحرك المحلي (بحث في الأدوية)
*/

function assistantPharmacyAll(): array
{
    return db()->query(
        'SELECT id, name_ar, name_en, generic_name, strength, price, quantity, description
         FROM medicines ORDER BY name_ar'
    )->fetchAll(PDO::FETCH_ASSOC);
}

function assistantKbStockLookup(array $entry, array $medicines): ?array
{
    $kbHaystack = assistantNormalize($entry['name_ar'] . ' ' . $entry['generic']);

    foreach ($medicines as $m) {
        $medHaystack = assistantNormalize($m['name_ar'] . ' ' . $m['name_en'] . ' ' . $m['generic_name']);

        if ($medHaystack !== '' && (mb_strpos($medHaystack, assistantNormalize($entry['name_ar'])) !== false
            || mb_strpos($medHaystack, assistantNormalize($entry['generic'])) !== false
            || mb_strpos($kbHaystack, assistantNormalize($m['name_ar'])) !== false
            || mb_strpos($kbHaystack, assistantNormalize($m['generic_name'])) !== false)) {
            return $m;
        }
    }

    return null;
}

function assistantLocalAnswer(string $question): string
{
    $words     = assistantQuestionWords($question);
    $phrases   = assistantQuestionPhrases($question);
    $medicines = assistantPharmacyAll();

    $pharmacy = [];
    foreach ($medicines as $m) {
        $haystack = assistantNormalize(
            $m['name_ar'] . ' ' . $m['name_en'] . ' ' .
            $m['generic_name'] . ' ' . $m['strength'] . ' ' .
            (string) $m['description']
        );

        $score = $words ? assistantScoreWords($words, $haystack, $phrases) : 0;
        if ($score > 0) {
            $pharmacy[] = ['medicine' => $m, 'score' => $score];
        }
    }

    usort($pharmacy, fn($a, $b) => $b['score'] <=> $a['score']);
    $pharmacy = array_slice($pharmacy, 0, 3);
    $kb = assistantKbSearch($question, 3);

    if (!$pharmacy && !$kb) {
        $names = implode('، ', array_unique(array_column(array_slice($medicines, 0, 10), 'name_ar')));

        return "لم أجد دواءً مطابقاً لسؤالك.\n\n" .
               "الأدوية المتوفرة في صيدليتنا: {$names}\n\n" .
               "جرّب ذكر اسم الدواء أو المادة الفعالة أو العرض الذي تشكو منه (مثال: دواء للصداع، مضاد حيوي، خافض للسكر).\n\n" .
               assistantDisclaimer();
    }

    $sections = [];

    if ($pharmacy) {
        $lines = [];
        foreach (array_slice($pharmacy, 0, 2) as $s) {
            $m     = $s['medicine'];
            $stock = ((int) $m['quantity']) > 0 ? 'متوفر' : 'غير متوفر حالياً';

            $lines[] = "{$m['name_ar']} ({$m['name_en']})\n" .
                       "• المادة الفعالة: {$m['generic_name']}\n" .
                       "• التركيز: {$m['strength']}\n" .
                       "• السعر: {$m['price']} جنيه\n" .
                       "• الحالة: {$stock}" .
                       ($m['description'] ? "\n• {$m['description']}" : '');
        }
        $sections[] = "من مخزون صيدليتنا:\n\n" . implode("\n\n", $lines);
    }

    if ($kb) {
        $lines = [];
        foreach (array_slice($kb, 0, 2) as $k) {
            $stockLine = '';
            $match = assistantKbStockLookup($k, $medicines);
            if ($match !== null) {
                $stockLine = "\n• التوفر في صيدليتنا: " .
                    ((((int) $match['quantity']) > 0)
                        ? "متوفر بسعر {$match['price']} جنيه"
                        : 'غير متوفر حالياً');
            } elseif ($medicines) {
                $stockLine = "\n• التوفر في صيدليتنا: غير مسجل بالمخزون حالياً";
            }

            $lines[] = "{$k['name_ar']} ({$k['name_en']})\n" .
                       "• المادة الفعالة: {$k['generic']}\n" .
                       "• التصنيف: {$k['category']}\n" .
                       "• الاستخدام: {$k['uses']}\n" .
                       "• الجرعة المعتادة: {$k['dose']}\n" .
                       "• تحذيرات: {$k['warnings']}" . $stockLine;
        }
        $sections[] = "معلومات الدواء من قاعدة المعرفة:\n\n" . implode("\n\n", $lines);
    }

    return implode("\n\n" . str_repeat('─', 20) . "\n\n", $sections) . "\n\n" . assistantDisclaimer();
}

/*
   6) الواجهة الرئيسية للمكتبة
*/

function assistantAsk(string $question, int $userId): array
{
    $answer = assistantCallApi($question, $userId);

    if ($answer !== null) {
        return ['answer' => $answer, 'source' => 'assistant'];
    }

    return ['answer' => assistantLocalAnswer($question), 'source' => 'local'];
}