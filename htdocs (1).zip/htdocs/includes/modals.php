<!-- Favorites and history -->
<div class="modal fade" id="listModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content p-4 rounded-4">

            <div class="modal-head d-flex justify-content-between align-items-center">
                <div style="min-width:0">
                    <h5 class="fw-bold mb-0" id="listModalTitle"></h5>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
            </div>

            <div id="listModalBody" class="mt-2"></div>

        </div>
    </div>
</div>

<!-- Pharmacy Assistant -->
<div class="modal fade" id="assistantChatModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content p-4 rounded-4">

            <div class="modal-head d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="fw-bold mb-0">
                        المساعد الذكي للأدوية
                    </h5>
                    <p class="text-muted small mb-0 mt-1">اسأل عن الأدوية والجرعات والتفاعلات.</p>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
            </div>

            <div class="assistant-messages mt-3" id="assistantMessages" style="max-height: 300px; overflow-y: auto;"></div>

            <div class="assistant-chips my-2" id="assistantChips"></div>

            <div class="assistant-input-group d-flex gap-2">
                <input id="assistantInput" class="form-control" placeholder="اكتب سؤالك عن الأدوية..." autocomplete="off">
                <button type="button" class="btn btn-primary" onclick="assistantSendQuestion()">
                    إرسال
                </button>
            </div>

        </div>
    </div>
</div>