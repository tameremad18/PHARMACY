/* =================================================_
   Smart Pharmacy Assistant - Chat JS (Direct Modal Control)
   ================================================= */

function openAssistantModal() {
    var modal = document.getElementById('assistantChatModal');
    if (modal) {
        modal.style.display = 'block';
        modal.classList.add('show');
        modal.style.backgroundColor = 'rgba(0, 0, 0, 0.5)'; // خلفية معتمة خفيفة
        document.body.classList.add('modal-open');
        
        // التركيز على حقل الإدخال تلقائياً عند الفتح
        setTimeout(function() {
            var input = document.getElementById('assistantInput');
            if (input) input.focus();
        }, 100);
    }
}

function closeAssistantModal() {
    var modal = document.getElementById('assistantChatModal');
    if (modal) {
        modal.style.display = 'none';
        modal.classList.remove('show');
        modal.style.backgroundColor = '';
        document.body.classList.remove('modal-open');
    }
}

// دالة إرسال السؤال إلى ملف الـ API
function assistantSendQuestion() {
    const input = document.getElementById('assistantInput');
    const messagesContainer = document.getElementById('assistantMessages');
    
    if (!input || !input.value.trim()) return;

    const question = input.value.trim();
    input.value = '';

    // عرض رسالة المستخدم في نافذة المحادثة
    if (messagesContainer) {
        messagesContainer.innerHTML += `<div class="user-message mb-2 text-end"><b>أنت:</b> ${escapeHtml(question)}</div>`;
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    // إرسال الطلب للخلفية (API)
    fetch(APP_URL + 'api/assistant.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ question: question })
    })
    .then(response => response.json())
    .then(data => {
        if (messagesContainer) {
            const reply = data.answer || data.error || 'عذراً، حدث خطأ في الرد.';
            messagesContainer.innerHTML += `<div class="assistant-message mb-2 text-start"><b>المساعد:</b> ${escapeHtml(reply)}</div>`;
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        if (messagesContainer) {
            messagesContainer.innerHTML += `<div class="text-danger mb-2">عذراً، تعذر الاتصال بالخادم.</div>`;
        }
    });
}

// دالة مساعدة لتأمين النصوص ضد ثغرات الـ XSS
function escapeHtml(text) {
    var map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, function(m) { return map[m]; });
}

// تفعيل زر الإغلاق وأزرار الـ Modal تلقائياً عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    var closeBtns = document.querySelectorAll('#assistantChatModal .btn-close, #assistantChatModal [data-bs-dismiss="modal"]');
    closeBtns.forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            closeAssistantModal();
        });
    });

    // إرسال السؤال عند الضغط على زر Enter داخل حقل الإدخال
    var input = document.getElementById('assistantInput');
    if (input) {
        input.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                assistantSendQuestion();
            }
        });
    }
});