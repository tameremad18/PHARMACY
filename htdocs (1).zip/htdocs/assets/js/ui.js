/*
   ui.js — أدوات الواجهة
   - فتح/غلق المودالات + الخلفية المعتمة + زر ESC
*/

(function (global) {
    'use strict';

    var backdrop = null;

    function resolve(target) {
        if (!target) return null;
        return typeof target === 'string' ? document.getElementById(target) : target;
    }

    function ensureBackdrop() {
        if (backdrop) return backdrop;

        backdrop = document.createElement('div');
        backdrop.className = 'modal-backdrop fade show';
        backdrop.addEventListener('click', function () {
            var open = document.querySelector('.modal.show');
            if (open) closeModal(open);
        });
        document.body.appendChild(backdrop);

        return backdrop;
    }

    function openModal(target) {
        var modal = resolve(target);
        if (!modal) return null;

        ensureBackdrop().classList.add('show');
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';

        var first = modal.querySelector('input, button, [tabindex]');
        if (first) first.focus({ preventScroll: true });

        modal.dispatchEvent(new CustomEvent('shown'));
        return modal;
    }

    function closeModal(target) {
        var modal = resolve(target);
        if (!modal || !modal.classList.contains('show')) return;

        modal.classList.remove('show');
        modal.dispatchEvent(new CustomEvent('hidden'));

        if (!document.querySelector('.modal.show')) {
            if (backdrop) backdrop.classList.remove('show');
            document.body.style.overflow = '';
        }
    }

    function toggleModal(target) {
        var modal = resolve(target);
        if (!modal) return;
        if (modal.classList.contains('show')) closeModal(modal);
        else openModal(modal);
    }

    /* إغلاق بأي عنصر يحمل data-close-modal داخل مودال */
    document.addEventListener('click', function (event) {
        var trigger = event.target.closest('[data-close-modal]');
        if (!trigger) return;

        var modal = trigger.closest('.modal');
        if (!modal) return;

        event.preventDefault();
        closeModal(modal);
    });

    /* مفتاح ESC يغلق آخر مودال مفتوح */
    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape') return;

        var open = document.querySelector('.modal.show');
        if (open) closeModal(open);
    });

    global.openModal   = openModal;
    global.closeModal  = closeModal;
    global.toggleModal = toggleModal;
})(window);
