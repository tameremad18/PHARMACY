/*
   Smart Pharmacy - Admin JS
   إدارة الأدوية (إضافة / تعديل / مسح باركود)
*/

/* ---------- إضافة دواء ---------- */

function showAddMedicine() {
    document.getElementById('medicineFormTitle').textContent = 'إضافة دواء';

    document.getElementById('medicineFormAction').value = 'add';
    document.getElementById('medicineFormId').value = '';

    ['fNameAr', 'fNameEn', 'fGeneric', 'fStrength', 'fBarcode', 'fDescription']
        .forEach(id => document.getElementById(id).value = '');

    document.getElementById('fPrice').value = '0';
    document.getElementById('fQuantity').value = '0';

    openModal('medicineFormModal');
}

/* ---------- تعديل دواء ---------- */

function editMedicine(med) {
    document.getElementById('medicineFormTitle').textContent =
        'تعديل: ' + med.name_ar;

    document.getElementById('medicineFormAction').value = 'update';
    document.getElementById('medicineFormId').value = med.id;

    document.getElementById('fNameAr').value      = med.name_ar;
    document.getElementById('fNameEn').value      = med.name_en;
    document.getElementById('fGeneric').value     = med.generic_name;
    document.getElementById('fStrength').value    = med.strength;
    document.getElementById('fBarcode').value     = med.barcode;
    document.getElementById('fDescription').value = med.description || '';
    document.getElementById('fPrice').value       = med.price;
    document.getElementById('fQuantity').value    = med.quantity;

    openModal('medicineFormModal');
}

/* ---------- مسح الباركود من كاميرا المدير ---------- */

let adminScanner = null;

function scanBarcode() {
    openModal('adminScannerModal');
    setTimeout(startAdminScanner, 500);
}

function startAdminScanner() {
    if (adminScanner) return;

    adminScanner = new Html5Qrcode('adminReader');

    adminScanner.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 250, height: 150 } },
        code => {
            document.getElementById('fBarcode').value = code;
            stopAdminScanner();

            closeModal('adminScannerModal');

            showToast('تم قراءة الباركود: ' + code, 'success');
        }
    ).catch(() => {
        showToast('تعذر تشغيل الكاميرا، أدخل الباركود يدوياً', 'error');
    });
}

function stopAdminScanner() {
    if (adminScanner) {
        adminScanner.stop()
            .then(() => adminScanner.clear())
            .catch(() => {});
        adminScanner = null;
    }
}

/*
   المسح السريع: موجود → تعديل / جديد → إضافة بالباركود
 */

let quickScanner = null;

/* خريطة الأدوية الحالية (تُملأ من الصفحة) */
let adminMedicinesMap = null;

function getAdminMedicinesMap() {
    if (adminMedicinesMap) return adminMedicinesMap;

    adminMedicinesMap = {};

    document.querySelectorAll('.meds-table tbody tr').forEach(() => {});

    /* نعتمد على زر التعديل: data-med غير متاح، فنبني الخريطة من المخزون المخفي */
    const hidden = document.getElementById('adminMedsData');

    if (hidden) {
        try {
            adminMedicinesMap = JSON.parse(hidden.textContent);
        } catch (e) {
            adminMedicinesMap = {};
        }
    }

    return adminMedicinesMap;
}

function barcodeVariants(code) {
    const clean = String(code).replace(/\D/g, '');
    if (!clean) return [];

    const v = [clean];
    if (clean.length === 13 && clean[0] === '0') v.push(clean.slice(1));
    if (clean.length === 12) v.push('0' + clean);
    return [...new Set(v)];
}

function findByBarcode(code) {
    const variants = barcodeVariants(code);
    const map = getAdminMedicinesMap();

    for (const med of Object.values(map)) {
        const stored = String(med.barcode || '').replace(/\D/g, '');
        if (stored && variants.includes(stored)) return med;
    }
    return null;
}

function openQuickScan() {
    openModal('quickScanModal');
    setTimeout(startQuickScan, 500);
}

function startQuickScan() {
    if (quickScanner) return;

    const status = document.getElementById('quickScanStatus');

    quickScanner = new Html5Qrcode('quickScanReader');

    quickScanner.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 250, height: 150 } },
        code => quickScanFound(code)
    ).catch(() => {
        showToast('تعذر تشغيل الكاميرا', 'error');
        status.textContent = 'تعذر تشغيل الكاميرا. تأكد من السماح للمتصفح باستخدامها.';
    });
}

function quickScanFound(code) {
    stopQuickScan();

    closeModal('quickScanModal');

    const med = findByBarcode(code);

    if (med) {
        showToast('مسجل: ' + med.name_ar + ' — فتح للتعديل', 'success');
        setTimeout(() => editMedicine(med), 300);
        return;
    }

    /* دواء جديد: افتح نموذج الإضافة والباركود جاهز */
    showToast('باركود جديد — افتح نموذج الإضافة', 'success');
    setTimeout(() => {
        showAddMedicine();
        document.getElementById('fBarcode').value = code;
    }, 300);
}

function stopQuickScan() {
    if (quickScanner) {
        quickScanner.stop()
            .then(() => quickScanner.clear())
            .catch(() => {});
        quickScanner = null;
    }
}
