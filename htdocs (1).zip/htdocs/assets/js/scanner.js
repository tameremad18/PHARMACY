/*
   Smart Pharmacy - Barcode Scanner
   مسح الباركود بالكاميرا والبحث عن الدواء
*/

let scanner = null;

function openScanner() {
    openModal('scannerModal');
    setTimeout(startScanner, 500);
}

function startScanner() {
    if (scanner) return;

    scanner = new Html5Qrcode('reader');

    scanner.start(
        { facingMode: 'environment' },
        { fps: 10, qrbox: { width: 250, height: 150 } },
        barcode => findBarcode(barcode)
    ).catch(() => {
        showToast('تعذر تشغيل الكاميرا. تأكد من السماح للمتصفح باستخدام الكاميرا.', 'error');
    });
}

function findBarcode(code) {
    stopScanner();

    closeModal('scannerModal');

    /* المرحلة 1: بحث محلي فوري */
    fetch(APP_URL + 'api/barcode.php?code=' + encodeURIComponent(code))
        .then(r => r.json())
        .then(data => {
            if (data.found) {
                openMedicine(data.id);
                return;
            }

            /* غير مسجل: افتح الشات فوراً بمقترحات عملية */
            openAssistantChat();
            setTimeout(() => {
                assistantAddMessage('user', 'باركود: ' + (data.code || code));
                assistantAddMessage('bot',
                    data.message + '\n\n' +
                    'جاري سؤال المساعد الذكي عن الباركود...\n' +
                    'أو صور العلبة من زر "صورة الدواء"\n' +
                    'أو اكتب اسم الدواء في شريط البحث');

                /* المرحلة 2: طلب إجابة المساعد في الخلفية */
                fetch(APP_URL + 'api/barcode.php?code=' + encodeURIComponent(data.code || code) + '&assistant=1')
                    .then(r => r.json())
                    .then(d2 => {
                        if (d2.assistantHint) {
                            assistantAddMessage('bot', d2.assistantHint);
                        } else {
                            assistantAddMessage('bot', 'لم أتعرف على الباركود. جرّب كتابة اسم الدواء أو تصوير العلبة.');
                        }
                    })
                    .catch(() => {});
            }, 800);
        })
        .catch(() => showToast('حدث خطأ في البحث عن الباركود', 'error'));
}

function stopScanner() {
    if (scanner) {
        scanner.stop()
            .then(() => scanner.clear())
            .catch(() => {});
        scanner = null;
    }
}
