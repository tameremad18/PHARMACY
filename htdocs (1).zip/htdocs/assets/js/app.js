/*
   Smart Pharmacy - App JS (مشترك)
   التوست + أدوات مساعدة
*/

function showToast(message, type = '') {
    const box = document.getElementById('toastBox');
    if (!box) return;

    const div = document.createElement('div');
    div.className = 'toast-msg ' + type;
    div.innerText = message;
    box.appendChild(div);

    setTimeout(() => div.remove(), 3000);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.innerText = text ?? '';
    return div.innerHTML;
}

/*
   USER APP
*/

let searchTimer = null;

document.addEventListener('DOMContentLoaded', function () {
    const searchInput = document.getElementById('search');
    if (searchInput) {
        searchInput.addEventListener('input', searchMedicine);
    }
});

/* ---------- البحث ---------- */

function searchMedicine() {
    const query = document.getElementById('search').value.trim();
    const result = document.getElementById('searchResults');

    if (!query) {
        result.innerHTML = '';
        return;
    }

    clearTimeout(searchTimer);

    searchTimer = setTimeout(() => {
        result.innerHTML = `
            <div class="admin-card mt-3 text-muted">
                جاري البحث...
            </div>`;

        fetch(APP_URL + 'api/search.php?q=' + encodeURIComponent(query))
            .then(r => r.json())
            .then(data => {
                const local = data.medicines || [];
                const kb = data.kb || [];

                if (local.length === 0 && kb.length === 0) {
                    /* لا نتائج محلية — اعرض إجابة المساعد الذكي إن وجدت */
                    if (data.assistant) {
                        result.innerHTML = `
                            <div class="admin-card mt-3">
                                <strong>إجابة المساعد الذكي</strong>
                                <div class="small" style="font-size:13px;line-height:2">
                                    ${escapeHtml(data.assistant).replace(/\n/g, '<br>')}
                                </div>
                                <button class="btn btn-sm btn-light rounded-4 mt-2" onclick="openAssistantChat()">
                                    أكمل الحوار مع المساعد
                                </button>
                            </div>`;
                        return;
                    }

                    result.innerHTML = `
                        <div class="admin-card mt-3">
                            لا يوجد دواء بهذا الاسم.
                            <br>
                            <small class="text-muted">جرّب المساعد الذكي للسؤال عن أي دواء في العالم</small>
                            <br>
                            <button class="btn btn-sm btn-light rounded-4 mt-2" onclick="openAssistantChat()">
                                اسأل المساعد الذكي
                            </button>
                        </div>`;
                    return;
                }

                let html = '';

                /* نتائج مخزون الصيدلية */
                html += local.map(m => `
                    <div class="admin-card mt-3" style="cursor:pointer" onclick="openMedicine(${m.id})">
                        <div class="d-flex align-items-center gap-2 flex-wrap">
                            <strong>${escapeHtml(m.name_ar)}</strong>
                            <span class="badge-stock in">متوفر بالصيدلية</span>
                        </div>
                        <br>
                        <small class="text-muted">
                            <span class="mono" dir="ltr">${escapeHtml(m.name_en)}</span> · <span class="mono">${escapeHtml(m.strength)}</span>
                        </small>
                    </div>
                `).join('');

                /* نتائج قاعدة المعرفة */
                html += kb.map(k => `
                    <div class="admin-card mt-3" style="cursor:pointer" onclick='openKbMedicine(${JSON.stringify(k).replace(/'/g, "&#39;")})'>
                        <div class="d-flex align-items-center gap-2 flex-wrap">
                            <strong>${escapeHtml(k.name_ar)}</strong>
                            <span class="badge-stock ${k.in_stock ? 'in' : 'low'}">${k.in_stock ? 'متوفر بالصيدلية' : 'معلومات دواء'}</span>
                        </div>
                        <br>
                        <small class="text-muted">
                            <span class="mono" dir="ltr">${escapeHtml(k.name_en)}</span> · <span class="mono">${escapeHtml(k.generic)}</span>
                        </small>
                    </div>
                `).join('');

                result.innerHTML = html;
            })
            .catch(() => showToast('حدث خطأ في البحث', 'error'));
    }, 300);
}

/* ---------- تفاصيل دواء من قاعدة المعرفة ---------- */

function openKbMedicine(k) {
    const body = document.getElementById('medicineModalBody');

    body.innerHTML = `
        <div class="medicine-head">
            <div>
                <h5 class="fw-bold mb-0">${escapeHtml(k.name_ar)}</h5>
                <small class="mono text-muted" dir="ltr">${escapeHtml(k.name_en)}</small>
            </div>
        </div>

        <div class="record">
            <span class="meta">ورقة الجزيء</span>
            <div class="row-data">
                <span class="meta">المادة الفعالة</span>
                <span class="val accent">${escapeHtml(k.generic)}</span>
            </div>
            <div class="row-data">
                <span class="meta">التصنيف</span>
                <span class="val">${escapeHtml(k.category)}</span>
            </div>
            <div class="row-data">
                <span class="meta">التوفر</span>
                <span class="val ${k.in_stock ? 'cy' : 'bad'}">${k.in_stock ? 'متوفر بالصيدلية' : 'غير مسجّل بالمخزون'}</span>
            </div>
        </div>

        <div class="record">
            <span class="meta">تعليمات الاستعمال</span>
            <div class="row-data">
                <span class="meta">الاستعمال</span>
                <span class="val prose">${escapeHtml(k.uses)}</span>
            </div>
        </div>

        <div class="record">
            <span class="meta">الجرعة المعتادة</span>
            <div class="row-data">
                <span class="meta">الجرعة</span>
                <span class="val prose">${escapeHtml(k.dose)}</span>
            </div>
        </div>

        <div class="record" style="border-color:rgba(255,178,36,.32)">
            <span class="meta" style="color:var(--amber)">تحذيرات</span>
            <div class="row-data">
                <span class="meta warn">تنبيه</span>
                <span class="val prose warn">${escapeHtml(k.warnings)}</span>
            </div>
        </div>

        <div class="alert alert-light small mb-0 mt-2">
            معلومات إرشادية فقط ولا تُغني عن استشارة الطبيب أو الصيدلي.
        </div>
    `;

    openModal('medicineModal');
}

/* ---------- تفاصيل الدواء ---------- */

function openMedicine(id) {
    fetch(APP_URL + 'api/medicine.php?id=' + id)
        .then(r => r.json())
        .then(data => {
            if (data.status !== 'ok') {
                showToast(data.message, 'error');
                return;
            }

            renderMedicineModal(data.medicine);
        })
        .catch(() => showToast('تعذر جلب بيانات الدواء', 'error'));
}

function renderMedicineModal(m) {
    const body = document.getElementById('medicineModalBody');
    const qty  = Number(m.quantity) || 0;
    const stock = qty > LOW_STOCK_MAX ? 'in' : (qty > 0 ? 'low' : 'out');
    const fill  = Math.min(100, Math.round((qty / LOW_STOCK_MAX) * 100));
    const gauge = qty > LOW_STOCK_MAX ? '' : (qty > 0 ? ' warn' : ' bad');

    body.innerHTML = `
        <div class="medicine-head">
            <div>
                <h5 class="fw-bold mb-0">${escapeHtml(m.name_ar)}</h5>
                <small class="mono text-muted" dir="ltr">${escapeHtml(m.name_en)}</small>
            </div>
        </div>

        <div class="record">
            <span class="meta">بطاقة الصنف</span>
            <div class="row-data">
                <span class="meta">المادة الفعالة</span>
                <span class="val accent">${escapeHtml(m.generic_name)}</span>
            </div>
            <div class="row-data">
                <span class="meta">التركيز</span>
                <span class="val mono">${escapeHtml(m.strength)}</span>
            </div>
            <div class="row-data">
                <span class="meta">السعر</span>
                <span class="val mono">${escapeHtml(m.price)} SDG</span>
            </div>
            <div class="row-data">
                <span class="meta">الباركود</span>
                <span class="val mono cy" dir="ltr">${escapeHtml(m.barcode)}</span>
            </div>
            <div class="row-data">
                <span class="meta">المخزون</span>
                <span class="val"><span class="badge-stock ${stock}">${qty} قطعة</span></span>
                <span class="gauge"><i class="${gauge.trim()}" style="width:${qty > 0 ? Math.max(fill, 6) : 0}%"></i></span>
            </div>
        </div>

        ${m.description ? `
        <div class="record">
            <span class="meta">معلومات عن الدواء</span>
            <div class="row-data">
                <span class="meta">نبذة</span>
                <span class="val prose">${escapeHtml(m.description)}</span>
            </div>
        </div>` : ''}

        <button class="btn-pill dark w-100 mt-2 ${m.is_favorite ? 'accent' : ''}" onclick="toggleFavorite(${m.id}, this)">
            ${m.is_favorite ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
        </button>
    `;

    openModal('medicineModal');
}

/* ---------- المفضلة ---------- */

function toggleFavorite(id, btn) {
    const body = new FormData();
    body.append('id', id);
    body.append('action', 'favorite');

    fetch(APP_URL + 'api/medicine.php', { method: 'POST', body: body })
        .then(r => r.json())
        .then(data => {
            if (data.status !== 'ok') {
                showToast(data.message, 'error');
                return;
            }

            btn.classList.remove('accent', 'dark');
            btn.classList.add(data.favorite ? 'accent' : 'dark');

            if (data.favorite) {
                btn.innerHTML = 'إزالة من المفضلة';
                showToast('تمت الإضافة إلى المفضلة', 'success');
            } else {
                btn.innerHTML = 'إضافة إلى المفضلة';
                showToast('تمت الإزالة من المفضلة');
            }
        })
        .catch(() => showToast('حدث خطأ', 'error'));
}

function showFavorites() {
    fetch(APP_URL + 'api/favorites.php')
        .then(r => r.json())
        .then(data => showListModal('الأدوية المفضلة', data.favorites))
        .catch(() => showToast('حدث خطأ', 'error'));
}

function showHistory() {
    fetch(APP_URL + 'api/history.php')
        .then(r => r.json())
        .then(data => showListModal('سجل البحث', data.history))
        .catch(() => showToast('حدث خطأ', 'error'));
}

function showListModal(title, items) {
    document.getElementById('listModalTitle').textContent = title;

    const body = document.getElementById('listModalBody');

    if (!items || items.length === 0) {
        body.innerHTML = `
            <div class="alert alert-light rounded-4 text-center mb-0">
                لا توجد عناصر بعد.
            </div>`;
    } else {
        body.innerHTML = items.map(m => `
            <div class="admin-card mt-0 mb-2" style="cursor:pointer" onclick="openFromList(${m.id})">
                <div class="d-flex align-items-center gap-3">
                    <div>
                        <strong>${escapeHtml(m.name_ar)}</strong>
                        <br>
                        <small class="text-muted">
                            ${escapeHtml(m.name_en)} - ${escapeHtml(m.strength)}
                        </small>
                    </div>
                </div>
            </div>
        `).join('');
    }

    openModal('listModal');
}

function openFromList(id) {
    closeModal('listModal');
    openMedicine(id);
}

/* ---------- صورة الدواء (التعرف على الدواء) ---------- */

function openImage() {
    openModal('imageModal');
}

function imageSelected(input) {
    if (!input.files.length) return;

    const file = input.files[0];
    input.value = '';

    if (!file.type.startsWith('image/')) {
        showToast('اختر ملف صورة صحيح', 'error');
        return;
    }

    const box = document.getElementById('imageResult');

    box.innerHTML = `
        <div class="alert alert-light rounded-4 text-center">
            <small>جاري تحليل الصورة والتعرف على الدواء... قد يستغرق ثوانٍ</small>
        </div>`;

    resizeImageForAssistant(file, 1024).then(({ base64, mime }) => {
        const body = new FormData();
        body.append('image', base64);
        body.append('mime', mime);

        return fetch(APP_URL + 'api/medscan.php', { method: 'POST', body: body });
    })
    .then(r => r.json())
    .then(data => {
        if (data.status !== 'ok') {
            box.innerHTML = `
                <div class="alert alert-danger rounded-4">
                    ${escapeHtml(data.message || 'حدث خطأ')}
                </div>`;
            return;
        }

        if (!data.found) {
            box.innerHTML = `
                <div class="alert alert-warning rounded-4">
                    ${escapeHtml(data.message)}
                </div>`;
            return;
        }

        const med = data.medicine;

        box.innerHTML = `
            <div class="alert alert-success rounded-4">
                <strong>تم التعرف على الدواء:</strong> ${escapeHtml(med.name_ar || med.name_en)}
                ${med.generic ? '<br><small class="text-muted">المادة الفعالة: ' + escapeHtml(med.generic) + '</small>' : ''}
            </div>
            <div class="admin-card small" style="font-size:13px;line-height:2">
                ${escapeHtml(data.answer).replace(/\n/g, '<br>')}
            </div>`;
    })
    .catch(() => {
        box.innerHTML = `
            <div class="alert alert-danger rounded-4">
                تعذر رفع الصورة، حاول مرة أخرى
            </div>`;
    });
}

/* ضغط الصورة في المتصفح قبل الإرسال (توفير للباقة وسرعة للرفع) */
function resizeImageForAssistant(file, maxSize) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();

        reader.onload = e => {
            const img = new Image();

            img.onload = () => {
                let { width, height } = img;

                if (width > maxSize || height > maxSize) {
                    const scale = Math.min(maxSize / width, maxSize / height);
                    width  = Math.round(width * scale);
                    height = Math.round(height * scale);
                }

                const canvas = document.createElement('canvas');
                canvas.width  = width;
                canvas.height = height;

                canvas.getContext('2d').drawImage(img, 0, 0, width, height);

                const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
                resolve({ base64: dataUrl.split(',')[1], mime: 'image/jpeg' });
            };

            img.onerror = () => reject(new Error('bad image'));
            img.src = e.target.result;
        };

        reader.onerror = () => reject(new Error('read error'));
        reader.readAsDataURL(file);
    });
}

/* ---------- التنقل ---------- */

function setActiveNav(element) {
    document.querySelectorAll('.nav').forEach(nav => nav.classList.remove('active'));
    element.classList.add('active');
}

function home() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}
