<?php

/*
   إعدادات قاعدة البيانات (XAMPP الافتراضية)
*/

define('DB_HOST', 'sql106.infinityfree.com');
define('DB_NAME', 'if0_43203212_ph');
define('DB_USER', 'if0_43203212');
define('DB_PASS', 'PHARMACY2026');
define('DB_CHARSET', 'utf8mb4');

function db(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die('<div style="font-family:sans-serif;padding:30px;text-align:center;direction:rtl">
                    <h2>فشل الاتصال بقاعدة البيانات</h2>
                    <p>تأكد من تشغيل MySQL في XAMPP واستيراد قاعدة البيانات
                    <code>database/smart_pharmacy.sql</code> أو افتح
                    <a href="install.php">install.php</a></p>
                 </div>');
        }
    }

    return $pdo;
}
