<?php

/* إعدادات المساعد الذكي
   المفتاح يُقرأ من متغير البيئة SMART_PHARMACY_ASSISTANT_API_KEY.
   بدون مفتاح يعمل المحرك المحلي فقط (البحث الذكي في الأدوية).

   المزود: gemini | openai | openrouter | deepseek
   gemini هو الوحيد الذي يدعم الصور مجاناً في المستوى الأساسي. */

$envPath = __DIR__ . '/../.env';
if (file_exists($envPath)) {
    $lines = file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if ($line === '' || $line[0] === '#') {
            continue;
        }
        if (str_contains($line, '=')) {
            list($key, $value) = array_map('trim', explode('=', $line, 2));
            if ($key !== '' && getenv($key) === false) {
                putenv("$key=$value");
                $_ENV[$key] = $value;
                $_SERVER[$key] = $value;
            }
        }
    }
}

define('ASSISTANT_PROVIDER', 'gemini');

/* لا تضع المفتاح داخل ملفات المشروع */
define('ASSISTANT_API_KEY', getenv('SMART_PHARMACY_ASSISTANT_API_KEY') ?: '');

// تم تعديل النموذج إلى النسخة المدعومة رسمياً لضمان استقبال الردود بنجاح
define('ASSISTANT_MODEL', 'gemini-1.5-flash');

/* مدة الانتظار بالثواني */
define('ASSISTANT_TIMEOUT', 30);

/* أقصى عدد ردود للمستخدم في الساعة */
define('ASSISTANT_HOURLY_LIMIT', 30);

/* أقل مدة بين كل سؤال والذي يليه بالثواني */
define('ASSISTANT_COOLDOWN', 3);