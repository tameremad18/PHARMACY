<?php

/*
   رأس لوحة تحكم المدير
   المتغيرات: $pageTitle ، $currentPage
*/

require_once __DIR__ . '/../../includes/functions.php';

$user        = requireAdmin();
$pageTitle   = $pageTitle ?? 'لوحة التحكم - Smart Pharmacy';
$currentPage = $currentPage ?? '';
$isAdminArea = true;

require_once __DIR__ . '/../../includes/header.php';
?>

<div class="admin-container">

    <div class="admin-topbar">
        <div class="admin-topbar-inner">

            <div class="d-flex align-items-center gap-3">
                <div>
                    <h4 class="mb-0">Smart Pharmacy</h4>
                    <small>لوحة تحكم المدير</small>
                </div>
            </div>

            <div class="d-flex align-items-center gap-2">
                <span class="admin-who">مرحباً، <?= e($user['name']) ?></span>
                <a class="btn-pill sm ghost" href="<?= url('auth/logout.php') ?>">
                    خروج
                </a>
            </div>

        </div>

        <nav class="admin-menu">
            <a href="<?= url('admin/medicines.php') ?>" class="<?= $currentPage === 'medicines' ? 'active' : '' ?>">
                الأدوية
            </a>
            <a href="<?= url('admin/users.php') ?>" class="<?= $currentPage === 'users' ? 'active' : '' ?>">
                المستخدمون
            </a>
            <a href="<?= url('home.php') ?>">
                تطبيق المستخدم
            </a>
        </nav>
    </div>

    <main class="admin-content">