    </main>

</div>

<?php

$extraScripts   = $extraScripts ?? [];
if (!in_array('assets/js/admin.js', $extraScripts, true)) {
    $extraScripts[] = 'assets/js/admin.js';
}

require_once __DIR__ . '/../../includes/footer.php';
