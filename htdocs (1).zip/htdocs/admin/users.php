 <?php

/*
   لوحة التحكم - المستخدمون
*/

$currentPage = 'users';
$pageTitle   = 'المستخدمون - Smart Pharmacy';

require_once __DIR__ . '/includes/admin_header.php';

/* عمود الهاتف غير موجود في كل قواعد البيانات — نفحصه قبل الاستعلام */
$hasPhone = (bool) db()->query('SHOW COLUMNS FROM users LIKE "phone"')->fetch();

$users = db()->query(
    'SELECT u.id, u.name, u.email, u.role, u.created_at,
            (SELECT COUNT(*) FROM favorites f WHERE f.user_id = u.id) AS favorites_count
     FROM users u
     ORDER BY u.id DESC'
)->fetchAll();

if ($hasPhone) {
    $phones = [];
    foreach (db()->query('SELECT id, phone FROM users')->fetchAll() as $row) {
        $phones[(int) $row['id']] = $row['phone'];
    }
} else {
    $phones = [];
}
?>

<div class="admin-card">
    <div class="d-flex align-items-center gap-3">

        <div class="flex-grow-1">
            <div class="row-data" style="padding:0">
                <span class="meta">المستخدمون المسجلون</span>
                <span class="val accent"><?= count($users) ?> مستخدم</span>
            </div>
        </div>

    </div>
</div>


<div class="table-wrap">
    <table class="meds-table">

        <thead>
            <tr>
                <th>الاسم</th>
                <th>البريد الإلكتروني</th>
                <th>الهاتف</th>
                <th>النوع</th>
                <th>المفضلة</th>
                <th>تاريخ التسجيل</th>
            </tr>
        </thead>

        <tbody>
        <?php foreach ($users as $u): ?>
            <?php $phone = $phones[(int) $u['id']] ?? null; ?>
            <tr>

                <td data-label="الاسم">
                    <span class="med-name"><?= e($u['name']) ?></span>
                </td>

                <td data-label="البريد الإلكتروني">
                    <span class="mono" dir="ltr"><?= e($u['email']) ?></span>
                </td>

                <td data-label="الهاتف">
                    <?php if (!empty($phone)): ?>
                        <span class="mono" dir="ltr"><?= e($phone) ?></span>
                    <?php else: ?>
                        <span class="text-muted mono">—</span>
                    <?php endif; ?>
                </td>

                <td data-label="النوع">
                    <span class="badge-role <?= e($u['role']) ?>">
                        <?= $u['role'] === 'admin' ? 'مدير' : 'مستخدم' ?>
                    </span>
                </td>

                <td data-label="المفضلة"><span class="mono"><?= (int) $u['favorites_count'] ?></span></td>

                <td data-label="تاريخ التسجيل">
                    <small class="text-muted mono" dir="ltr"><?= date('Y-m-d', strtotime($u['created_at'])) ?></small>
                </td>

            </tr>
        <?php endforeach; ?>
        </tbody>

    </table>
</div>

<?php require_once __DIR__ . '/includes/admin_footer.php'; ?>
