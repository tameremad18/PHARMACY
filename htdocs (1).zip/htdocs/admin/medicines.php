<?php

/*
   لوحة التحكم - إدارة الأدوية (إضافة / تعديل / حذف)
*/

require_once __DIR__ . '/../includes/functions.php';

$user = requireAdmin();

/*
   معالجة العمليات (POST)
*/

$messages = [
    'added'   => 'تمت إضافة الدواء بنجاح',
    'updated' => 'تم تحديث بيانات الدواء بنجاح',
    'deleted' => 'تم حذف الدواء بنجاح',
    'exists'  => 'هذا الباركود مسجل لدواء آخر بالفعل',
    'error'   => 'حدث خطأ، تأكد من تعبئة جميع الحقول',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? '';

    /* ---------- حذف ---------- */

    if ($action === 'delete') {
        $stmt = db()->prepare('DELETE FROM medicines WHERE id = ?');
        $stmt->execute([(int) $_POST['id']]);
        redirect(url('admin/medicines.php') . '?msg=deleted');
    }

    /* ---------- إضافة / تعديل ---------- */

    if ($action === 'add' || $action === 'update') {

        $id          = (int) ($_POST['id'] ?? 0);
        $nameAr      = trim($_POST['name_ar'] ?? '');
        $nameEn      = trim($_POST['name_en'] ?? '');
        $genericName = trim($_POST['generic_name'] ?? '');
        $strength    = trim($_POST['strength'] ?? '');
        $barcode     = trim($_POST['barcode'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $price       = (float) ($_POST['price'] ?? 0);
        $quantity    = max(0, (int) ($_POST['quantity'] ?? 0));

        if ($nameAr === '' || $nameEn === '' || $genericName === '' || $strength === '' || $barcode === '') {
            redirect(url('admin/medicines.php') . '?msg=error');
        }

        try {
            if ($action === 'add') {
                $stmt = db()->prepare(
                    'INSERT INTO medicines (name_ar, name_en, generic_name, strength, barcode, description, price, quantity)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
                );
                $stmt->execute([$nameAr, $nameEn, $genericName, $strength, $barcode, $description, $price, $quantity]);
                redirect(url('admin/medicines.php') . '?msg=added');
            }

            $stmt = db()->prepare(
                'UPDATE medicines
                 SET name_ar = ?, name_en = ?, generic_name = ?, strength = ?, barcode = ?, description = ?, price = ?, quantity = ?
                 WHERE id = ?'
            );
            $stmt->execute([$nameAr, $nameEn, $genericName, $strength, $barcode, $description, $price, $quantity, $id]);
            redirect(url('admin/medicines.php') . '?msg=updated');
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                redirect(url('admin/medicines.php') . '?msg=exists');
            }
            redirect(url('admin/medicines.php') . '?msg=error');
        }
    }
}

/*
   عرض الصفحة
*/

$currentPage = 'medicines';
$pageTitle   = 'إدارة الأدوية - Smart Pharmacy';

require_once __DIR__ . '/includes/admin_header.php';

/* رسالة النتيجة */
$flash = $_GET['msg'] ?? '';
if (isset($messages[$flash])) {
    $flashIsError = ($flash === 'error' || $flash === 'exists');
    echo '<div class="alert ' . ($flashIsError ? 'alert-danger' : 'alert-success') . ' rounded-4">'
        . e($messages[$flash])
        . '</div>';
}

/* البحث */
$q   = trim($_GET['q'] ?? '');
$like = '%' . $q . '%';

$sql = 'SELECT * FROM medicines';
$args = [];

if ($q !== '') {
    $sql .= ' WHERE name_ar LIKE ? OR name_en LIKE ? OR barcode LIKE ?';
    $args = [$like, $like, $like];
}

$sql .= ' ORDER BY id DESC';

$stmt = db()->prepare($sql);
$stmt->execute($args);
$medicines = $stmt->fetchAll();

/* كل الأدوية للمسح السريع (غير متأثرة بفلتر البحث) */
$medsForScan = array_map(fn($med) => [
    'id'           => (int) $med['id'],
    'name_ar'      => $med['name_ar'],
    'name_en'      => $med['name_en'],
    'generic_name' => $med['generic_name'],
    'strength'     => $med['strength'],
    'barcode'      => $med['barcode'],
    'description'  => (string) $med['description'],
    'price'        => (float) $med['price'],
    'quantity'     => (int) $med['quantity'],
], db()->query('SELECT * FROM medicines ORDER BY id')->fetchAll());
?>

<div class="admin-card">
    <div class="d-flex align-items-center gap-3 flex-wrap">

        <div class="flex-grow-1">
            <div class="row-data" style="padding:0">
                <span class="meta">إدارة الأدوية</span>
                <span class="val accent"><?= count($medicines) ?> دواء<?= $q !== '' ? ' · نتائج: ' . e($q) : '' ?></span>
            </div>
        </div>

        <button class="btn btn-primary" style="width:auto" onclick="showAddMedicine()">
            إضافة دواء
        </button>

    </div>
</div>


<!-- البحث -->
<form method="get" class="search mb-3">
    <input name="q" value="<?= e($q) ?>" placeholder="ابحث بالاسم أو الباركود..." autocomplete="off">
</form>


<!-- القائمة -->
<?php if (!$medicines): ?>

    <div class="admin-card text-center text-muted">
        لا توجد أدوية<?= $q !== '' ? ' مطابقة للبحث' : '' ?>.
    </div>

<?php else: ?>

    <div class="table-wrap">
        <table class="meds-table">

            <thead>
                <tr>
                    <th>الدواء</th>
                    <th>المادة الفعالة</th>
                    <th>الباركود</th>
                    <th>السعر</th>
                    <th>إجراءات</th>
                </tr>
            </thead>

            <tbody>
            <?php foreach ($medicines as $med): ?>
                <tr>

                    <td data-label="الدواء">
                        <span class="med-name"><?= e($med['name_ar']) ?></span>
                        <br>
                        <small class="text-muted"><?= e($med['name_en']) ?> · <?= e($med['strength']) ?></small>
                    </td>

                    <td data-label="المادة الفعالة"><span class="mono"><?= e($med['generic_name']) ?></span></td>

                    <td data-label="الباركود"><span class="mono" dir="ltr"><?= e($med['barcode']) ?></span></td>

                    <td data-label="السعر"><span class="mono"><?= number_format((float) $med['price'], 2) ?></span> SDG</td>

                    <td data-label="إجراءات">
                        <div class="d-flex gap-2">
                            <button
                                class="btn btn-warning btn-sm"
                                onclick='editMedicine(<?= json_encode($med, JSON_UNESCAPED_UNICODE | JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'
                            >
                                تعديل
                            </button>

                            <form
                                method="post"
                                onsubmit="return confirm('هل تريد حذف الدواء <?= e($med['name_ar']) ?>؟')"
                                class="d-inline"
                            >
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= (int) $med['id'] ?>">
                                <button type="submit" class="btn btn-danger btn-sm">
                                    حذف
                                </button>
                            </form>
                        </div>
                    </td>

                </tr>
            <?php endforeach; ?>
            </tbody>

        </table>
    </div>

<?php endif; ?>

<script type="application/json" id="adminMedsData"><?=
    json_encode(array_values($medsForScan), JSON_UNESCAPED_UNICODE | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_TAG | JSON_HEX_AMP)
?></script>


<!-- نافذة إضافة / تعديل دواء -->

<div class="modal fade" id="medicineFormModal">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content p-4 rounded-4">

            <h5 class="fw-bold mb-3" id="medicineFormTitle">
                إضافة دواء
            </h5>

            <form method="post" id="medicineForm">

                <input type="hidden" name="action" value="add" id="medicineFormAction">
                <input type="hidden" name="id" value="" id="medicineFormId">

                <div class="row g-3">

                    <div class="col-md-6">
                        <label class="form-label">اسم الدواء (عربي) <span class="text-danger">*</span></label>
                        <input name="name_ar" id="fNameAr" class="form-control" placeholder="مثال: بنادول" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">اسم الدواء (إنجليزي) <span class="text-danger">*</span></label>
                        <input name="name_en" id="fNameEn" class="form-control" placeholder="Panadol" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">المادة الفعالة <span class="text-danger">*</span></label>
                        <input name="generic_name" id="fGeneric" class="form-control" placeholder="باراسيتامول" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">التركيز <span class="text-danger">*</span></label>
                        <input name="strength" id="fStrength" class="form-control" placeholder="500 مجم" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">الباركود <span class="text-danger">*</span></label>
                        <div class="d-flex gap-2">
                            <input name="barcode" id="fBarcode" class="form-control" placeholder="امسحه أو أدخله يدوياً" required>
                            <button type="button" class="btn btn-outline-secondary" onclick="scanBarcode()" title="مسح بالكاميرا">
                                مسح
                            </button>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">السعر (جنيه سوداني - SDG)</label>
                        <input name="price" id="fPrice" type="number" step="0.01" min="0" class="form-control" placeholder="0.00" value="0">
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">الكمية</label>
                        <input name="quantity" id="fQuantity" type="number" min="0" class="form-control" placeholder="0" value="0">
                    </div>

                    <div class="col-12">
                        <label class="form-label">وصف الدواء</label>
                        <textarea name="description" id="fDescription" class="form-control" rows="3" placeholder="طريقة الاستخدام وتفاصيل إضافية (اختياري)"></textarea>
                    </div>

                </div>

                <button type="submit" class="main-btn mt-4">
                    حفظ الدواء
                </button>

            </form>

        </div>
    </div>
</div>


<!-- نافذة مسح الباركود -->

<div class="modal fade" id="adminScannerModal">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content p-3 rounded-4">

            <div class="modal-head">
                <div>
                    <h5 class="fw-bold mb-0">
                        مسح الباركود
                    </h5>
                    <p class="small text-muted mb-0 mt-1">وجّه الكاميرا إلى باركود الدواء ليُعبأ تلقائياً.</p>
                </div>
                <button type="button" class="btn-close" onclick="stopAdminScanner()" data-close-modal aria-label="إغلاق"></button>
            </div>

            <div class="scanner mt-2">
                <div id="adminReader"></div>
            </div>

        </div>
    </div>
</div>

<!-- نافذة المسح السريع -->

<div class="modal fade" id="quickScanModal">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content p-3 rounded-4">

            <div class="modal-head">
                <div>
                    <h5 class="fw-bold mb-0">
                        مسح سريع
                    </h5>
                    <p class="small text-muted mb-0 mt-1" id="quickScanStatus">
                        امسح باركود الدواء: إن كان مسجلاً فُتح للتعديل فوراً، وإن كان جديداً فُتحت إضافته بالباركود جاهزاً.
                    </p>
                </div>
                <button type="button" class="btn-close" onclick="stopQuickScan()" data-close-modal aria-label="إغلاق"></button>
            </div>

            <div class="scanner mt-2">
                <div id="quickScanReader"></div>
            </div>

        </div>
    </div>
</div>


<script src="<?= url('assets/js/html5-qrcode.min.js') ?>"></script>

<?php
$extraScripts = ['assets/js/admin.js', 'assets/js/scanner.js'];
require_once __DIR__ . '/includes/admin_footer.php';
?>
