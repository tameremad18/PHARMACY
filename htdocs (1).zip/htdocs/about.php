<?php

/* Smart Pharmacy - معلومات التطبيق */

require_once __DIR__ . '/includes/functions.php';

$user = requireLogin();

$pageTitle   = 'معلومات التطبيق - Smart Pharmacy';
$userSite    = true;
$extraScripts = ['assets/js/chat.js'];

require_once __DIR__ . '/includes/header.php';
?>

<div class="site">

    <!-- شريط العنوان -->
    <div class="userbar">
        <div class="userbar-inner">
            <div class="userbar-copy">
                <h2>معلومات التطبيق</h2>
            </div>
        </div>
    </div>

    <!-- المحتوى -->
    <div class="page-pad">
        <div class="admin-card about-card">
            <h4>اقرأ أي دواء<br>كما يقرؤه <em>المختبِر</em></h4>
            <p>
                سمّ المركّب، أو امسح الباركود، أو صوّر العلبة — واقرأ الاستخدام والجرعة
                والتحذيرات في قارئ واحد، مع مساعد صيدلي يجيب بلغتك.
            </p>
        </div>
    </div>

</div>


<footer class="site-footer">
    <div class="tick thin"></div>
    <div class="site-footer-inner">

        <div class="brand">
            <span class="brand-text">
                <strong>Smart Pharmacy</strong>
                <small>الصيدلية الذكية</small>
            </span>
        </div>

        <div class="footer-links">
            <a href="<?= url('home.php') ?>">الرئيسية</a>
            <a href="<?= url('about.php') ?>">معلومات التطبيق</a>
            <a href="<?= url('auth/logout.php') ?>">تسجيل الخروج</a>
        </div>

    </div>
</footer>


<?php require_once __DIR__ . '/includes/modals.php'; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
