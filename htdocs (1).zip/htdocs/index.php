<?php

/*
   نقطة الدخول الرئيسية
   توجه المستخدم حسب حالة الجلسة والصلاحية
*/

require_once __DIR__ . '/includes/functions.php';

if (!isLoggedIn()) {
    redirect(url('auth/login.php'));
}

redirect(isAdmin() ? url('admin/medicines.php') : url('home.php'));
