<?php

/*
   صفحة التثبيت - تشغيلها مرة واحدة فقط
   تنشئ قاعدة البيانات والجداول والبيانات التجريبية
   يمكن حذف هذا الملف بعد التثبيت
*/

require_once __DIR__ . '/config/database.php';

header('Content-Type: text/html; charset=utf-8');

/* الاتصال بدون تحديد قاعدة بيانات لإنشائها أولاً */
try {
    $root = new PDO(
        'mysql:host=' . DB_HOST . ';charset=' . DB_CHARSET,
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die('<div style="font-family:sans-serif;padding:30px;text-align:center;direction:rtl">
            <h2>تعذر الاتصال بـ MySQL</h2>
            <p>تأكد من تشغيل Apache و MySQL من لوحة XAMPP ثم أعد المحاولة.</p>
         </div>');
}

$sqlFile = __DIR__ . '/database/smart_pharmacy.sql';

if (!file_exists($sqlFile)) {
    die('ملف database/smart_pharmacy.sql غير موجود');
}

$sql = file_get_contents($sqlFile);

try {
    /* تنفيذ كل استعلام على حدة */
    $root->exec($sql);

    echo '<div style="font-family:Tahoma,sans-serif;padding:40px;text-align:center;direction:rtl;background:#FFFFFF;color:#0A1730;min-height:100vh;box-sizing:border-box">
            <h1 style="color:#8C6B1C">تم تثبيت قاعدة البيانات بنجاح</h1>
            <p>تم إنشاء قاعدة البيانات والجداول والبيانات التجريبية.</p>
            <p><strong>حساب المدير:</strong> admin@smartpharmacy.com / admin123<br>
               <strong>حساب مستخدم تجريبي:</strong> user@smartpharmacy.com / 123456</p>
            <a href="auth/login.php" style="background:#1B3B8F;color:white;padding:14px 30px;border-radius:4px;
               text-decoration:none;font-weight:bold;display:inline-block;margin-top:10px">تسجيل الدخول</a>
            <p style="color:#5A6B8C;font-size:12px;margin-top:25px">يُنصح بحذف ملف install.php الآن.</p>
          </div>';
} catch (PDOException $e) {
    echo '<div style="font-family:sans-serif;padding:30px;text-align:center;direction:rtl">
            <h2>حدث خطأ أثناء التثبيت</h2>
            <p style="color:#b91c1c">' . htmlspecialchars($e->getMessage()) . '</p>
          </div>';
}
