<?php

/* Smart Pharmacy - User Home */

require_once __DIR__ . '/includes/functions.php';

$user = requireLogin();

$pageTitle    = 'Smart Pharmacy';
$userSite     = true;
// تم الاستغناء عن chat.js الخارجي لمنع أخطاء الحظر 403، والاعتماد على الكود المدمج في الفوتر
$extraScripts = ['assets/js/scanner.js'];

require_once __DIR__ . '/includes/header.php';
?>

<div class="site">

    <!-- شريط الترحيب -->
    <div class="userbar">
        <div class="userbar-inner">
            <div class="userbar-copy">
                <span class="eyebrow">لوحة المستخدم</span>
                <h2>أهلاً، <?= e($user['name']) ?></h2>
            </div>
            <span class="userbar-note">
                قراءة أدق للدواء = صرف أأمن
            </span>
        </div>
    </div>

    <!-- الجهاز -->
    <section class="hero-section">

        <div class="detector">

            <div class="detector-body">

                <div class="hero-search">
                    <div class="search">
                        <input
                            id="search"
                            placeholder="اكتب اسم الدواء… مثال: بنادول"
                            autocomplete="off"
                        >
                    </div>
                    <div id="searchResults"></div>
                    <p class="hero-search-hint">
                        تحتاج مساعدة؟ <a href="#" onclick="openAssistantModal(); return false;">اسأل المساعد الذكي</a>
                    </p>
                </div>

                <div class="hero-actions">
                    <button class="btn-pill accent" onclick="openScanner()">
                        مسح الباركود
                    </button>
                    <button class="btn-pill dark" onclick="openImage()">
                        صورة الدواء
                    </button>
                </div>

            </div>
        </div>

    </section>

</div>


<!-- Barcode scanner -->

<div class="modal fade" id="scannerModal">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content p-4 rounded-4">

            <div class="modal-head">
                <div>
                    <h5 class="fw-bold mb-0">
                        مسح الباركود
                    </h5>
                    <p class="text-muted small mb-0 mt-1">وجّه الكاميرا إلى باركود الدواء.</p>
                </div>
                <button type="button" class="btn-close" onclick="stopScanner()" data-close-modal aria-label="إغلاق"></button>
            </div>

            <div class="scanner mt-2">
                <div id="reader"></div>
            </div>

        </div>
    </div>
</div>


<!-- Medicine image -->

<div class="modal fade" id="imageModal">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content p-4 rounded-4">

            <div class="modal-head">
                <div>
                    <h5 class="fw-bold mb-0">صورة الدواء</h5>
                    <p class="text-muted small mb-0 mt-1">اختر طريقة تصوير الدواء.</p>
                </div>
                <button type="button" class="btn-close" data-close-modal aria-label="إغلاق"></button>
            </div>

            <div class="row g-3 mt-1">

                <div class="col-6">
                    <label class="img-option">
                        <span>الكاميرا</span>
                        <input type="file" accept="image/*" capture="environment" hidden onchange="imageSelected(this)">
                    </label>
                </div>

                <div class="col-6">
                    <label class="img-option">
                        <span>المعرض</span>
                        <input type="file" accept="image/*" hidden onchange="imageSelected(this)">
                    </label>
                </div>

            </div>

            <div id="imageResult" class="mt-3"></div>

        </div>
    </div>
</div>


<!-- Medicine details -->

<div class="modal fade" id="medicineModal">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content p-4 rounded-4 position-relative">

            <button type="button" class="btn-close modal-close-abs" data-close-modal aria-label="إغلاق"></button>

            <div id="medicineModalBody"></div>

            <button class="btn btn-light w-100 mt-3" data-close-modal>إغلاق</button>

        </div>
    </div>
</div>


<!-- Favorites, history and pharmacy assistant -->

<?php require_once __DIR__ . '/includes/modals.php'; ?>

<script src="<?= url('assets/js/html5-qrcode.min.js') ?>"></script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>