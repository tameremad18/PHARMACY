<?php

/*
   تسجيل الدخول — شاشة مستقلة (Smart Pharmacy)
*/

require_once __DIR__ . '/../includes/functions.php';

/* لو مسجل دخوله بالفعل نوجهه حسب صلاحيته */
if (isLoggedIn()) {
    redirect(isAdmin() ? url('admin/medicines.php') : url('home.php'));
}

$errors = [];
$oldLogin = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim($_POST['identifier'] ?? '');
    $password   = $_POST['password'] ?? '';
    $oldLogin   = $identifier;

    if ($identifier === '') {
        $errors[] = 'أدخل اسم المستخدم';
    }
    if ($password === '') {
        $errors[] = 'أدخل كلمة المرور';
    }

    if (!$errors) {
        /* بريد إلكتروني أولاً، ثم رقم الهاتف إن وُجد عمود الهاتف */
        $stmt = db()->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$identifier]);
        $user = $stmt->fetch();

        if (!$user) {
            $hasPhone = (bool) db()->query('SHOW COLUMNS FROM users LIKE "phone"')->fetch();
            if ($hasPhone) {
                $stmt = db()->prepare('SELECT * FROM users WHERE phone = ? LIMIT 1');
                $stmt->execute([$identifier]);
                $user = $stmt->fetch();
            }
        }

        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int) $user['id'];
            redirect($user['role'] === 'admin' ? url('admin/medicines.php') : url('home.php'));
        }

        $errors[] = 'اسم المستخدم أو كلمة المرور غير صحيحة';
    }
}

$pageTitle = 'تسجيل الدخول - Smart Pharmacy';
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#FFFFFF">

<title><?= e($pageTitle) ?></title>

<link href="<?= url('assets/css/fonts.css') ?>" rel="stylesheet">
<link href="<?= url('assets/css/login.css') ?>" rel="stylesheet">
</head>

<body>

<div class="screen">

    <!-- الشعار -->
    <header class="brand">

        <p class="brand__name">Smart Pharmacy</p>

    </header>

    <!-- النموذج -->
    <main class="main">

        <h1 class="title">تسجيل الدخول</h1>
        <p class="subtitle">أدخل بياناتك للوصول إلى لوحة التحكم</p>

        <?php if ($errors): ?>
            <div class="alert">
                <?php foreach ($errors as $error): ?>
                    <div><?= e($error) ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="post" class="form" autocomplete="on">

            <div class="field">
                <label class="label" for="loginIdentifier">اسم المستخدم</label>
                <div class="control">
                    <input
                        id="loginIdentifier"
                        type="text"
                        name="identifier"
                        value="<?= e($oldLogin) ?>"
                        placeholder="ادخل اسم المستخدم"
                        autocomplete="username"
                        autocapitalize="off"
                        spellcheck="false"
                        required
                    >
                </div>
            </div>

            <div class="field">
                <label class="label" for="loginPassword">كلمة المرور</label>
                <div class="control">
                    <input
                        id="loginPassword"
                        type="password"
                        name="password"
                        placeholder="ادخل كلمة المرور"
                        autocomplete="current-password"
                        required
                    >
                </div>
            </div>

            <label class="remember" for="remember">
                <input type="checkbox" name="remember" id="remember">
                <span>تذكرني</span>
            </label>

            <button type="submit" class="submit">
                <span>دخول</span>
            </button>

        </form>

        <p class="register">
            <span>ليس لديك حساب؟</span>
            <a href="<?= url('auth/register.php') ?>">إنشاء حساب جديد</a>
        </p>

    </main>

</div>

</body>
</html>
