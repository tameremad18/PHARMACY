<?php

/*
   إنشاء حساب جديد — شاشة مستقلة (Smart Pharmacy)
*/

require_once __DIR__ . '/../includes/functions.php';

if (isLoggedIn()) {
    redirect(url('home.php'));
}

$errors = [];
$old = ['name' => '', 'email' => '', 'phone' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $phone    = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';
    $old      = ['name' => $name, 'email' => $email, 'phone' => $phone];

    if (mb_strlen($name) < 2) {
        $errors[] = 'أدخل الاسم بشكل صحيح';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'البريد الإلكتروني غير صالح';
    }
    if ($phone !== '' && !preg_match('/^\+?[0-9]{10,15}$/', $phone)) {
        $errors[] = 'رقم الهاتف غير صالح (10 إلى 15 رقماً)';
    }
    if (mb_strlen($password) < 6) {
        $errors[] = 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';
    }
    if ($password !== $confirm) {
        $errors[] = 'كلمتا المرور غير متطابقتين';
    }

    if (!$errors) {
        $stmt = db()->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);

        if ($stmt->fetch()) {
            $errors[] = 'هذا البريد مسجل بالفعل';
        } else {
            $hasPhone = (bool) db()->query('SHOW COLUMNS FROM users LIKE "phone"')->fetch();

            if ($phone !== '' && $hasPhone) {
                $stmt = db()->prepare('SELECT id FROM users WHERE phone = ? LIMIT 1');
                $stmt->execute([$phone]);
                if ($stmt->fetch()) {
                    $errors[] = 'رقم الهاتف مسجل بالفعل';
                }
            }

            if (!$errors) {
                $hash = password_hash($password, PASSWORD_DEFAULT);

                if ($hasPhone) {
                    $stmt = db()->prepare('INSERT INTO users (name, email, phone, password, role) VALUES (?, ?, ?, ?, "user")');
                    $stmt->execute([$name, $email, $phone !== '' ? $phone : null, $hash]);
                } else {
                    $stmt = db()->prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, "user")');
                    $stmt->execute([$name, $email, $hash]);
                }

                $_SESSION['user_id'] = (int) db()->lastInsertId();
                redirect(url('home.php'));
            }
        }
    }
}

$pageTitle = 'إنشاء حساب - Smart Pharmacy';
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#FFFFFF">

<title><?= e($pageTitle) ?></title>

<link href="<?= url('assets/css/fonts.css') ?>" rel="stylesheet">
<link href="<?= url('assets/css/login.css') ?>" rel="stylesheet">
</head>

<body>

<div class="screen">

    <!-- الشعار -->
    <header class="brand">

        <p class="brand__name">Smart Pharmacy</p>

    </header>

    <!-- النموذج -->
    <main class="main">

        <h1 class="title">إنشاء حساب</h1>
        <p class="subtitle">أنشئ حسابك لتبقى مفضلاتك وسجل بحثك خاصاً بك</p>

        <?php if ($errors): ?>
            <div class="alert">
                <?php foreach ($errors as $error): ?>
                    <div><?= e($error) ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="post" class="form" autocomplete="on">

            <div class="field">
                <label class="label" for="regName">الاسم</label>
                <div class="control">
                    <input
                        id="regName"
                        type="text"
                        name="name"
                        value="<?= e($old['name']) ?>"
                        placeholder="أدخل اسمك"
                        autocomplete="name"
                        required
                    >
                </div>
            </div>

            <div class="field">
                <label class="label" for="regEmail">البريد الإلكتروني</label>
                <div class="control">
                    <input
                        id="regEmail"
                        type="email"
                        name="email"
                        value="<?= e($old['email']) ?>"
                        placeholder="name@example.com"
                        autocomplete="email"
                        required
                    >
                </div>
            </div>

            <div class="field">
                <label class="label" for="regPhone">رقم الهاتف (اختياري)</label>
                <div class="control">
                    <input
                        id="regPhone"
                        type="tel"
                        name="phone"
                        value="<?= e($old['phone']) ?>"
                        placeholder="01234567890"
                        autocomplete="tel"
                        dir="ltr"
                    >
                </div>
            </div>

            <div class="field">
                <label class="label" for="regPassword">كلمة المرور</label>
                <div class="control">
                    <input
                        id="regPassword"
                        type="password"
                        name="password"
                        placeholder="٦ أحرف على الأقل"
                        autocomplete="new-password"
                        required
                    >
                </div>
            </div>

            <div class="field">
                <label class="label" for="regConfirm">تأكيد كلمة المرور</label>
                <div class="control">
                    <input
                        id="regConfirm"
                        type="password"
                        name="confirm"
                        placeholder="أعد كتابة كلمة المرور"
                        autocomplete="new-password"
                        required
                    >
                </div>
            </div>

            <button type="submit" class="submit">
                <span>إنشاء الحساب</span>
            </button>

        </form>

        <p class="register">
            <span>لديك حساب بالفعل؟</span>
            <a href="<?= url('auth/login.php') ?>">تسجيل الدخول</a>
        </p>

    </main>

</div>

</body>
</html>
