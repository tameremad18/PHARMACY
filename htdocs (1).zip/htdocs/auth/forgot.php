<?php

/*
   نسيت كلمة المرور
*/

require_once __DIR__ . '/../includes/functions.php';

if (isLoggedIn()) {
    redirect(isAdmin() ? url('admin/medicines.php') : url('home.php'));
}

$sent = false;
$hasPhone = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');

    if ($login !== '') {
        $stmt = db()->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$login]);
        $found = $stmt->fetch();

        if (!$found) {
            $hasPhone = (bool) db()->query('SHOW COLUMNS FROM users LIKE "phone"')->fetch();
            if ($hasPhone) {
                $stmt = db()->prepare('SELECT id FROM users WHERE phone = ? LIMIT 1');
                $stmt->execute([$login]);
                $found = $stmt->fetch();
            }
        }

        /* في هذه النسخة يُرسل إشعار توضيحي دون خدمة بريد حقيقية */
        $sent = true;
    }
}

$pageTitle = 'نسيت كلمة المرور - Smart Pharmacy';
$hideSiteNav = true;
require_once __DIR__ . '/../includes/header.php';
?>

<div class="app auth-app">

    <div class="auth-screen">
        <div class="auth-layout">

            <div class="auth-card">
                <div class="mobile-brand">
                    <div>
                        <strong>صيدليتي الذكية</strong>
                        <small>Smart Pharmacy</small>
                    </div>
                </div>

                <div class="auth-heading">
                    <span>استعادة العيّنة</span>
                    <h2>نسيت كلمة المرور؟</h2>
                    <p>أدخل رقم هاتفك أو بريدك الإلكتروني وسنرسل لك خطوات الاستعادة</p>
                </div>

            <?php if ($sent): ?>
                <div class="alert alert-success mt-3 mb-0">
                    <div>
                        تم استلام طلبك. إذا كان الحساب موجوداً، ستصل خطوات استعادة كلمة المرور إلى بياناتك المسجلة.
                    </div>
                </div>
            <?php endif; ?>

            <form method="post" class="mt-4">

                <label class="form-label" for="forgotLogin">رقم الهاتف أو البريد الإلكتروني</label>
                <div class="input-wrap">
                    <input
                        id="forgotLogin"
                        type="text"
                        name="login"
                        class="form-control"
                        placeholder="01234567890 أو name@example.com"
                        autocomplete="username"
                        required
                    >
                </div>

                <button type="submit" class="main-btn">
                    <span>إرسال خطوات الاستعادة</span>
                </button>

            </form>

                <div class="register-block">
                    <span class="text-muted">تذكرت بياناتك؟</span>
                    <a class="secondary-btn" href="<?= url('auth/login.php') ?>">
                        العودة إلى تسجيل الدخول
                    </a>
                </div>

            </div>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>